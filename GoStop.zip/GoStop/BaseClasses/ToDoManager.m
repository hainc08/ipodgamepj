#import "ToDoManager.h"
static ToDoManager *ToDoManagerInst;

@implementation CardMove

@synthesize isSound;
@synthesize card;
@synthesize pos;
@synthesize isAni;
@synthesize isZoom;
@synthesize isShow;
@synthesize waitNext;
@synthesize next;
@synthesize justShow;

@end

@implementation ToDoManager

@synthesize ground;

+ (ToDoManager*)getInstance
{
	return ToDoManagerInst;
}

+ (void)initManager
{
	ToDoManagerInst = [ToDoManager alloc];
	ToDoManagerInst->head = NULL;
	ToDoManagerInst->tail = NULL;
	ToDoManagerInst->unUsedHead = NULL;
	ToDoManagerInst->waitTick = 0;
}

- (void)update
{
	if (waitTick == 0)
	{
		while((head != NULL)&&(waitTick == 0))
		{
			CardMove *cur = head;
			head = cur.next;
		
			if (cur.card != NULL)
			{
				[ground bringSubviewToFront:cur.card];

				if (cur.justShow)
				{
					if (cur.isShow) [cur.card setShow:true];
					else [cur.card setShow:false];
				}
				else
				{
					if (cur.isShow) [cur.card setShow:true];

					if (cur.isAni)
						[cur.card moveTo:cur.pos:cur.isZoom];
					else
						[cur.card moveToNoAni:cur.pos:cur.isZoom];
				}

				if (cur.isSound)
				{
					[cur.card playSound];
				}
			}
			
			waitTick = cur.waitNext;
			
			if (unUsedHead != NULL) [unUsedHead setNext:cur];
			else [cur setNext:NULL];
			unUsedHead = cur;
		}
	}
	else
	{
		--waitTick;
	}
}

- (void)addDelay:(int)delay
{
	[self addCardMove:NULL pos:CGPointMake(0,0) isAni:false isZoom:false isShow:false waitNext:delay];
}

- (bool)isMoveOver
{
	return (head == NULL);
}

- (void)addCardMoveWithSound:(Card*)card pos:(CGPoint)pos isAni:(bool)isAni isZoom:(bool)isZoom isShow:(bool)isShow waitNext:(int)waitNext
{
	[self addCardMove:card pos:pos isAni:isAni isZoom:isZoom isShow:isShow waitNext:waitNext];
	[tail setIsSound:true];
}

- (void)addCardMove:(Card*)card pos:(CGPoint)pos isAni:(bool)isAni isZoom:(bool)isZoom isShow:(bool)isShow waitNext:(int)waitNext
{
	CardMove *newMove;
	
	if (unUsedHead != NULL)
	{
		newMove = unUsedHead;
		unUsedHead = unUsedHead.next;
	}
	else
	{
		newMove = [CardMove alloc];
	}
	
	[newMove setCard:card];
	[newMove setPos:pos];
	[newMove setIsAni:isAni];
	[newMove setIsZoom:isZoom];
	[newMove setIsShow:isShow];
	[newMove setWaitNext:waitNext];
	[newMove setNext:NULL];
	[newMove setJustShow:false];
	[newMove setIsSound:false];
	
	if (head == NULL)
	{
		head = tail = newMove;
	}
	else
	{
		[tail setNext:newMove];
		tail = newMove;
	}
}

- (void)addCardShow:(Card*)card isShow:(bool)isShow waitNext:(int)waitNext
{
	CardMove *newMove;
	
	if (unUsedHead != NULL)
	{
		newMove = unUsedHead;
		unUsedHead = unUsedHead.next;
	}
	else
	{
		newMove = [CardMove alloc];
	}
	
	[newMove setCard:card];
	[newMove setIsShow:isShow];
	[newMove setWaitNext:waitNext];
	[newMove setNext:NULL];
	[newMove setJustShow:true];
	
	if (head == NULL)
	{
		head = tail = newMove;
	}
	else
	{
		[tail setNext:newMove];
		tail = newMove;
	}	
}

- (void)cardShake:(Card*)card1:(Card*)card2:(Card*)card3
{
	[self addCardMove:card1 pos:CGPointMake(80, 240) isAni:true isZoom:true isShow:true waitNext:0];
	[self addCardMove:card2 pos:CGPointMake(160, 240) isAni:true isZoom:true isShow:true waitNext:0];
	[self addCardMove:card3 pos:CGPointMake(240, 240) isAni:true isZoom:true isShow:true waitNext:5];
}

- (void)closeManager
{

}

@end
