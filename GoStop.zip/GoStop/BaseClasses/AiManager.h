#import "Player.h"

@interface AiManager : NSObject
{	
	Player* CPU;
	Player* MAN;
	float weight[10];
	Card **groundCard[12];
}

+ (AiManager*)getInstance;
+ (void)initManager;
- (void)closeManager;

- (void)setPlayer:(Player*)cpu:(Player*)man;
- (void)setGroundCard:(Card**)cards mark:(int)idx;

- (int)getNextCardIdx;
- (bool)GoOrStop;
- (float)getCardWeight:(Card*)card;

@end
