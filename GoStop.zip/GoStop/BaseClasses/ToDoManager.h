#import "../Classes/Card.h"

@interface CardMove : NSObject
{
	bool isSound;
	Card* card;
	CGPoint pos;
	bool isZoom;
	bool isAni;
	bool isShow;
	int waitNext;
	bool justShow;
	
	CardMove* next;
}

@property (retain) Card* card;
@property (readwrite) CGPoint pos;
@property (readwrite) bool isAni;
@property (readwrite) bool isZoom;
@property (readwrite) bool isShow;
@property (readwrite) bool isSound;
@property (readwrite) bool justShow;
@property (readwrite) int waitNext;
@property (retain) CardMove* next;

@end

@interface ToDoManager : NSObject
{
	CardMove* head;
	CardMove* tail;

	CardMove* unUsedHead;
	UInt32 waitTick;
	
	UIView* ground;
}

@property (retain) UIView* ground;

+ (ToDoManager*)getInstance;
- (void)update;
- (void)cardShake:(Card*)card1:(Card*)card2:(Card*)card3;
- (void)addCardMoveWithSound:(Card*)card pos:(CGPoint)pos isAni:(bool)isAni isZoom:(bool)isZoom isShow:(bool)isShow waitNext:(int)waitNext;
- (void)addCardMove:(Card*)card pos:(CGPoint)pos isAni:(bool)isAni isZoom:(bool)isZoom isShow:(bool)isShow waitNext:(int)waitNext;
- (void)addCardShow:(Card*)card isShow:(bool)isShow waitNext:(int)waitNext;
- (void)addDelay:(int)delay;
- (bool)isMoveOver;
+ (void)initManager;
- (void)closeManager;

@end
