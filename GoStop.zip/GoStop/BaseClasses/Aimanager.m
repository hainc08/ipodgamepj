#import "AiManager.h"
#import "GameRuleManager.h"

static AiManager *AiManagerInst;

@implementation AiManager

+ (AiManager*)getInstance
{
	return AiManagerInst;
}

+ (void)initManager;
{
	AiManagerInst = [AiManager alloc];
}

- (void)closeManager
{

}

- (void)setPlayer:(Player*)cpu:(Player*)man
{
	MAN = man;
	CPU = cpu;
}

- (float)getCardWeight:(Card*)card
{
	float w = 1;

	//점수를 낼 수 있는 카드를 찾아라...
	int initScore = [[GameRuleManager getInstance] getScore:CPU];
	int cardScore = [[GameRuleManager getInstance] getScoreWithCard:CPU card:card];

	if (initScore < cardScore) w *= 3;
	else
	{
		//점수를 낼 수 없는 카드라면 구질구질한 카드의 중요도를 낮춘다.
		switch (card.m_idx)
		{
			case 45:
			case 46:
				w *= 0.8;
				break;
			case 20:
			case 36:
				w *= 0.9;
				break;
		}
	}
	
	if (card.cardType == 0) w *= 2;
	else if (card.cardType == 4) w *= 1.5;
	
	return w;
}

- (int)getNextCardIdx
{
	int cardCount = CPU.m_handCardCount;
	Card* card;
	Card** cardp;
	
	for (int i=0; i<cardCount; ++i)
	{
		card = [CPU readFromHand:i];
		cardp = groundCard[[card getMark]];

		if (cardp[0] != NULL)
		{
			weight[i] = 10;
			if (cardp[1] != NULL) weight[i] -= 3;	//굳은자니까 중요도 하락...
			
			for (int j=0; j<3; ++j)
			{
				if (cardp[j] != NULL)
				{
					weight[i] *= [self getCardWeight:cardp[j]];
				}
			}
		}
		else
		{
			weight[i] = -10;
		}

		weight[i] *= [self getCardWeight:card];
	}
	
	float maxWeight = -999;
	int maxIdx = 0;
	for (int i=0; i<cardCount; ++i)
	{
		if (maxWeight < weight[i])
		{
			maxWeight = weight[i];
			maxIdx = i;
		}
	}
	
	return maxIdx;
}

- (void)setGroundCard:(Card**)cards mark:(int)idx;
{
	groundCard[idx] = cards;
}

- (bool)GoOrStop
{
	int goPer;
	int playerScore = [[GameRuleManager getInstance] getScore:MAN];
	
	switch (playerScore)
	{
		case 0: goPer = 100; break;
		case 1: goPer = 80; break;
		case 2: goPer = 60; break;
		case 3: goPer = 30; break;
		case 4: goPer = 0; break;
	}
	
	return (goPer > (rand()%100));
}

@end
