#import "GameRuleManager.h"
static GameRuleManager *gameRuleManagerInst;

@implementation GameRuleManager

@synthesize nanDouble;
@synthesize nagari;
@synthesize jabbuck;
@synthesize goBak;
@synthesize mission;
@synthesize showAll;
@synthesize ggang;

+ (GameRuleManager*)getInstance
{
	return gameRuleManagerInst;
}

+ (void)initManager
{
	gameRuleManagerInst = [GameRuleManager alloc];
	gameRuleManagerInst->nanDouble = false;
	gameRuleManagerInst->jabbuck = false;
	gameRuleManagerInst->mission = false;
	gameRuleManagerInst->showAll = false;
	gameRuleManagerInst->ggang = false;	
}

- (int)getScoreWithCard:(Player*)player card:(Card*)card
{
	[player setReserveCard:card];
	int score = [self getScore:player];
	[player setReserveCard:NULL];

	return score;
}

- (int)getScore:(Player*)player
{
	int score = 0;
	int cardCount;
	
	cardCount = [player getCardCount:0];
	switch (cardCount)
	{
		case 5:
			score += 15;
			break;
		case 4:
			score += 4;
			break;
		case 3:
			if ([player isEatCardOK:44]) score += 2;
			else score += 3;
			break;
	}
	
	cardCount = [player getCardCount:1];
	if (cardCount > 4) score += (cardCount - 4);

	cardCount = [player getCardCount:2];
	if (cardCount > 4) score += (cardCount - 4);
	
	cardCount = [player getCardCount:3] + ([player getCardCount:4] * 2);
	if (cardCount > 9) score += (cardCount - 9);

	if ([player isEatCardOK:1]&&[player isEatCardOK:5]&&[player isEatCardOK:9]) score += 3;
	if ([player isEatCardOK:13]&&[player isEatCardOK:17]&&[player isEatCardOK:25]) score += 3;
	if ([player isEatCardOK:21]&&[player isEatCardOK:33]&&[player isEatCardOK:37 ]) score += 3;
	if ([player isEatCardOK:4]&&[player isEatCardOK:12]&&[player isEatCardOK:29]) score += 5;

	return score;
}

- (int)getCardType:(int)idx
{
	//0-광, 1-열, 2-띠, 3-피, 4-쌍피
	int cardType = 3;
	
	//룰에따른 차이는 나중에...뉌뉌...
	switch(idx)
	{
		//광...
		case 0: case 8:
		case 28: case 40:
		case 44:
			cardType = 0;
			break;
		case 4: case 12:
		case 20: case 24:
		case 29: case 36:
		case 45:
			cardType = 1;
			break;
		case 1: case 5:
		case 9: case 13:
		case 17: case 21:
		case 25: case 33:
		case 37: case 46:
			cardType = 2;
			break;
		case 16: 
			if (nanDouble) cardType = 4;
			else cardType = 1;
			break;
		case 41: case 32:
		case 47:
			cardType = 4;
			break;
	}
	
	return cardType;
}

- (void)closeManager
{

}

@end
