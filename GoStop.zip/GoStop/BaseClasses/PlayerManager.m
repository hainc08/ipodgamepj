#import "PlayerManager.h"
#import "GameRuleManager.h"

static PlayerManager *PlayerManagerInst;

@implementation PlayerManager

@synthesize money;
@synthesize playerName;

+ (PlayerManager*)getInstance
{
	return PlayerManagerInst;
}

+ (void)initManager;
{
	PlayerManagerInst = [PlayerManager alloc];
	[PlayerManagerInst loadFromFile];
}

- (void)closeManager
{

}

- (void)setRecord:(int)idx value:(int) value
{
	record[idx] = value;
}

- (void)setRecordMax:(int)idx value:(int)value
{
	if (record[idx] < value) record[idx] += value;
}

- (void)setRecordAdd:(int)idx value:(int)value
{
	record[idx] += value;
}

- (int)getRecord:(int)idx
{
	return record[idx];
}

- (void)saveToFile
{
	NSArray *filePaths =	NSSearchPathForDirectoriesInDomains (
																 NSDocumentDirectory, 
																 NSUserDomainMask,
																 YES
																 ); 
	NSString* recordingDirectory = [filePaths objectAtIndex: 0];
	NSString* saveFile = [NSString stringWithFormat: @"%@/player.dat", recordingDirectory];

	NSString* text = [NSString stringWithFormat:@"%@\t%lld", playerName, money];

	NSFileHandle *writeFile = [NSFileHandle fileHandleForWritingAtPath:saveFile];
	if (writeFile == nil)
	{
		[[NSFileManager defaultManager] createFileAtPath:saveFile
												contents:nil attributes:nil];

		writeFile = [NSFileHandle fileHandleForWritingAtPath:saveFile];
	}
	
	int ruleByte = 0;

	if ([GameRuleManager getInstance].nanDouble) ruleByte |= 0x01;
	if ([GameRuleManager getInstance].jabbuck) ruleByte |= 0x02;
	if ([GameRuleManager getInstance].nagari) ruleByte |= 0x04;
	if ([GameRuleManager getInstance].goBak) ruleByte |= 0x08;
	if ([GameRuleManager getInstance].mission) ruleByte |= 0x10;
	if ([GameRuleManager getInstance].showAll) ruleByte |= 0x20;
	if ([GameRuleManager getInstance].ggang) ruleByte |= 0x40;
	
	if (writeFile == nil)
	{
		NSLog(@"fail to open file");
		return;
	}
	else
	{
		[writeFile writeData: [NSData dataWithBytes:record
											 length:sizeof(int)*20]];
		[writeFile writeData: [NSData dataWithBytes:&ruleByte
											 length:sizeof(int)]];
		NSData* d = [text dataUsingEncoding:NSUTF8StringEncoding];
		[writeFile writeData: d];
	}
    
	[writeFile closeFile];
}

- (void)resetInfo
{
	for (int i=0; i<20; ++i)
	{
		record[i] = 0;
	}
}

- (void)loadFromFile
{
	NSArray *filePaths =	NSSearchPathForDirectoriesInDomains (
																 NSDocumentDirectory, 
																 NSUserDomainMask,
																 YES
																 ); 
	NSString* recordingDirectory = [filePaths objectAtIndex: 0];
	NSString* saveFile = [NSString stringWithFormat: @"%@/player.dat", recordingDirectory];
	
	NSFileHandle *readFile;

	for (int i=0; i<20; ++i) record[i] = 0;
	
	readFile = [NSFileHandle fileHandleForReadingAtPath:saveFile];

	if(readFile == nil)
	{
		playerName = @"playerName";
		money = 1000000;
		return;
	}

    {
		NSData *data = [readFile readDataOfLength:sizeof(int)*20];
		[data getBytes:record];
	}

	{
		int ruleByte;
		NSData *data = [readFile readDataOfLength:sizeof(int)];
		[data getBytes:&ruleByte];

		[[GameRuleManager getInstance] setNanDouble:(ruleByte & 0x01)];
		[[GameRuleManager getInstance] setJabbuck:(ruleByte & 0x02)];
		[[GameRuleManager getInstance] setNagari:(ruleByte & 0x04)];
		[[GameRuleManager getInstance] setGoBak:(ruleByte & 0x08)];
		[[GameRuleManager getInstance] setMission:(ruleByte & 0x10)];
		[[GameRuleManager getInstance] setShowAll:(ruleByte & 0x20)];
		[[GameRuleManager getInstance] setGgang:(ruleByte & 0x40)];
	}
	
	{
		NSData *data = [readFile readDataToEndOfFile];
		NSString* text = [[NSString alloc] initWithData: data 
											   encoding: NSUTF8StringEncoding];
		int textSize = [text length];
	
		for (int i=0; i<textSize; ++i)
		{
			if ([text characterAtIndex:i] == '\t')
			{
				playerName = [[NSString alloc] initWithString:[text substringToIndex:i]];
				money = [[text substringFromIndex:i+1] longLongValue];
				break;
			}
		}
	}
		
	[readFile closeFile];
}

- (long long)addMoney:(long long)amount
{
	money += amount;
	
	return money;
}

- (long long)subMoney:(long long)amount
{
	if (money < amount)
	{
		//파산...
	}
	else
	{
		money -= amount;
	}
	
	return money;
}

@end
