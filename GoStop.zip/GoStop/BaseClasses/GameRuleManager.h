#import "../Classes/Player.h"

@interface GameRuleManager : NSObject
{
	bool nanDouble;
	bool jabbuck;
	bool nagari;
	bool goBak;
	bool mission;
	bool showAll;
	bool ggang;
}

@property (readwrite) bool nanDouble;
@property (readwrite) bool jabbuck;
@property (readwrite) bool nagari;
@property (readwrite) bool goBak;
@property (readwrite) bool mission;
@property (readwrite) bool showAll;
@property (readwrite) bool ggang;

+ (GameRuleManager*)getInstance;
+ (void)initManager;
- (void)closeManager;
- (int)getCardType:(int)idx;
- (int)getScore:(Player*)player;
- (int)getScoreWithCard:(Player*)player card:(Card*)card;

@end
