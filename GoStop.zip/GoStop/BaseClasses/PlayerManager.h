
@interface PlayerManager : NSObject
{	
	long long money;
	NSString* playerName;
	
	int record[20];
}

@property (readwrite) long long money;
@property (retain) NSString* playerName;

+ (PlayerManager*)getInstance;
+ (void)initManager;
- (void)closeManager;

- (void)setRecord:(int)idx value:(int) value;
- (void)setRecordMax:(int)idx value:(int)value;
- (void)setRecordAdd:(int)idx value:(int)value;
- (int)getRecord:(int)idx;

- (void)resetInfo;
- (void)loadFromFile;
- (void)saveToFile;
- (long long)addMoney:(long long)amount;
- (long long)subMoney:(long long)amount;

@end
