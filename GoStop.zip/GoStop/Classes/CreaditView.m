#import "CreaditView.h"
#import "ViewManager.h"

@implementation CreaditView

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	//여기는 단순한 화면터치...
}

- (IBAction)ButtonClick:(id)sender
{
	if (sender == MainMenuButton)
	{
		[[ViewManager getInstance] changeView:@"MainMenuView"];
	}
}

- (void)reset:(NSObject*)param
{
	[super reset:param];

    [ProgramImg setAlpha:0.0];
    [ArtImg setAlpha:0.0];
	[DirectImg setAlpha:0.0];
	[TeamLogo setAlpha:0.0];
	[self clearCreaditText:false];
	[MainMenuButton setAlpha:0.3];
	
	creaditTextIdx = 0;
}

- (void)addCreaditText:(NSString*)str
{
	if (creaditTextIdx == 5) return;

	id showLabel;
	switch (creaditTextIdx)
	{
		case 0:
			showLabel = creaditText1;
			break;
		case 1:
			showLabel = creaditText2;
			break;
		case 2:
			showLabel = creaditText3;
			break;
		case 3:
			showLabel = creaditText4;
			break;
		case 4:
			showLabel = creaditText5;
			break;
	}
	
	[showLabel setText:str];

	[UIView beginAnimations:@"show" context:NULL];
	[UIView setAnimationDuration:1.0];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	[showLabel setAlpha:1.0];
	[UIView commitAnimations];
	
	++creaditTextIdx;
}

- (void)clearCreaditText:(bool)isAni
{
	if (isAni)
	{
		[UIView beginAnimations:@"clear" context:NULL];
		[UIView setAnimationDuration:1.5];
		[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	}

	[creaditText1 setAlpha:0.0];
	[creaditText2 setAlpha:0.0];
	[creaditText3 setAlpha:0.0];
	[creaditText4 setAlpha:0.0];
	[creaditText5 setAlpha:0.0];
	
	creaditTextIdx = 0;

	if (isAni) [UIView commitAnimations];
}

- (void)showImg:(id)img
{
	[UIView beginAnimations:@"showImg" context:NULL];
	[UIView setAnimationDuration:1.0];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];

	[img setAlpha:1.0];

	[UIView commitAnimations];
}

- (void)hideImg:(id)img
{
	[UIView beginAnimations:@"showImg" context:NULL];
	[UIView setAnimationDuration:1.5];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	
	[img setAlpha:0.0];
	
	[UIView commitAnimations];
}

- (void)update
{
	[super update];

	switch (frameTick)
	{
		case 5: [self showImg:TeamLogo]; break;
		case 20: [self hideImg:TeamLogo]; break;
		case 40: [self showImg:DirectImg]; break;
		case 50: [self addCreaditText:@"Producer : Sasin"]; break;
		case 55: [self addCreaditText:@"Director : Sasin"]; break;
		case 60: [self addCreaditText:@"Game Designer : Sasin"]; break;
		case 80: [self clearCreaditText:true]; [self hideImg:DirectImg]; break;

		case 90: [self showImg:ProgramImg]; break;
		case 100: [self addCreaditText:@"Lead Programer : Sasin"]; break;
		case 105: [self addCreaditText:@"Architect Programer : Sasin"]; break;
		case 110: [self addCreaditText:@"UI Programer : Sasin"]; break;
		case 115: [self addCreaditText:@"Tool Programer : Sasin"]; break;
		case 135: [self clearCreaditText:true]; [self hideImg:ProgramImg]; break;

		case 145: [self showImg:ArtImg]; break;
		case 155: [self addCreaditText:@"Graphic Cheif : Sasin"]; break;
		case 160: [self addCreaditText:@"Artwork : Sasin"]; break;
		case 165: [self addCreaditText:@"UI Designer : Sasin"]; break;
		case 170: [self addCreaditText:@"2D Graphic : Sasin"]; break;
		case 175: [self addCreaditText:@"Technical Art Director : Sasin"]; break;
		case 195: [self clearCreaditText:true]; [self hideImg:ArtImg];break;

		case 215:
		{
			[UIView beginAnimations:@"showImg" context:NULL];
			[UIView setAnimationDuration:1.0];
			[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
			
			[TeamLogo setAlpha:1.0];
			[creaditText5 setAlpha:1.0];
			[creaditText5 setText:@"Oink Studio 2008. 12."];
			[MainMenuButton setAlpha:1];
			
			[UIView commitAnimations];
		}
	}
}

@end
