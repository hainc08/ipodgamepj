#import "Card.h"
#import "../BaseClasses/GameRuleManager.h"

@implementation Card

@synthesize m_idx;
@synthesize m_pos;
@synthesize cardType;
@synthesize isBomb;

- (void)setCard:(int)idx
{
	m_idx = idx;
	[CardImg setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%d_%d.png", (idx / 4) + 1, (idx % 4) + 1]]];
	[self setShow:false];	
	cardType = [[GameRuleManager getInstance] getCardType:idx];

	NSBundle *mainBundle = [NSBundle mainBundle];
	tickSound = [[SoundEffect alloc] initWithContentsOfFile:[mainBundle pathForResource:@"tick" ofType:@"wav"]];
}

- (void)playSound
{
	[tickSound play];
}

- (int)getMark
{
	return m_idx / 4;
}

- (void)Zoom:(bool)isZoom
{
	if (isZoom)
		[UIView beginAnimations:@"zoomIn" context:NULL];
	else
		[UIView beginAnimations:@"zoomOut" context:NULL];
		
	[UIView setAnimationDuration:0.2];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];

	if (isZoom)
		self.transform = CGAffineTransformMake(0.3, 0.0, 0.0, 0.3, m_pos.x, m_pos.y - 30.f);
	else
		self.transform = CGAffineTransformMake(0.20, 0.0, 0.0, 0.20, m_pos.x, m_pos.y);

	[UIView commitAnimations];
}

- (void)setShow:(bool)isShow
{
	if ([GameRuleManager getInstance].showAll) isShow = true;
	
	if (isShow)
	{
		[CardImg setAlpha:1.0f];
		[BackImg setAlpha:0.0f];
	}
	else
	{
		[CardImg setAlpha:0.0f];
		[BackImg setAlpha:1.0f];
	}

	[self setEable:false];
}

- (void)setEable:(bool)eable
{
	if (eable)
		[EableImg setAlpha:1.0f];
	else
		[EableImg setAlpha:0.0f];
}

- (void)moveTo:(int)x:(int)y:(bool)isZoom
{
	[UIView beginAnimations:@"move" context:NULL];
	[UIView setAnimationDuration:0.2];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	
	if (isZoom) self.transform = CGAffineTransformMake(0.5, 0.0, 0.0, 0.5, x, y);
	else self.transform = CGAffineTransformMake(0.20, 0.0, 0.0, 0.20, x, y);

	m_pos.x = x;
	m_pos.y = y;
	[UIView commitAnimations];
}

- (void)moveTo:(CGPoint)pos:(bool)isZoom
{
	[self moveTo:pos.x:pos.y:isZoom];
}

- (void)moveToNoAni:(int)x:(int)y:(bool)isZoom
{
	if (isZoom) self.transform = CGAffineTransformMake(0.5, 0.0, 0.0, 0.5, x, y);
	else self.transform = CGAffineTransformMake(0.20, 0.0, 0.0, 0.20, x, y);

	m_pos.x = x;
	m_pos.y = y;
}

- (void)moveToNoAni:(CGPoint)pos:(bool)isZoom
{
	[self moveToNoAni:pos.x:pos.y:isZoom];
}

- (void)dealloc
{
    [tickSound release];
    [super dealloc];
}

@end
