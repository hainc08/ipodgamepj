#import "Mission.h"
#import "ViewManager.h"

@implementation Mission

@synthesize jjockCount;
@synthesize panCount;
@synthesize missionIdx;

- (void)init
{
	cards[0] = (Card*)([[ViewManager getInstance] getInstView:@"Card"]);
	cards[1] = (Card*)([[ViewManager getInstance] getInstView:@"Card"]);
	cards[2] = (Card*)([[ViewManager getInstance] getInstView:@"Card"]);
	
	[self addSubview:cards[0]];
	[self addSubview:cards[1]];
	[self addSubview:cards[2]];

	[cards[0] setCenter:CGPointMake(80, 75)];
	[cards[1] setCenter:CGPointMake(160, 75)];
	[cards[2] setCenter:CGPointMake(240, 75)];

	cards[0].transform = CGAffineTransformMake(0.4, 0.0, 0.0, 0.4, 0, 0);
	cards[1].transform = CGAffineTransformMake(0.4, 0.0, 0.0, 0.4, 0, 0);
	cards[2].transform = CGAffineTransformMake(0.4, 0.0, 0.0, 0.4, 0, 0);
}

- (void)setMission:(int)idx
{
	missionIdx = idx;
	if (missionIdx == -1) return;

	[cards[0] setAlpha:1];
	[cards[1] setAlpha:1];
	[cards[2] setAlpha:1];
	[missionImg1 setAlpha:0];
	[missionImg2 setAlpha:0];
    [x2 setAlpha:1];
    [x3 setAlpha:0];

	switch (missionIdx)
	{
		case 0:
			[cards[0] setCard:1];
			[cards[1] setCard:5];
			[cards[2] setCard:9];
			break;
		case 1:
			[cards[0] setCard:13];
			[cards[1] setCard:17];
			[cards[2] setCard:25];
			break;
		case 2:
			[cards[0] setCard:21];
			[cards[1] setCard:33];
			[cards[2] setCard:37];
			break;
		case 3:
			[cards[0] setCard:4];
			[cards[1] setCard:12];
			[cards[2] setCard:29];
			break;
		case 4:
			[cards[0] setAlpha:0];
			[cards[1] setAlpha:0];
			[cards[2] setAlpha:0];
			[missionImg1 setAlpha:1];
			[x2 setAlpha:0];
			[x3 setAlpha:1];		
			break;
		case 5:
			[cards[0] setAlpha:0];
			[cards[1] setAlpha:0];
			[cards[2] setAlpha:0];
			[missionImg2 setAlpha:1];
			break;
	}

	[cards[0] setShow:true];
	[cards[1] setShow:true];
	[cards[2] setShow:true];
}

- (bool)checkMission:(Player*)player
{
	switch (missionIdx)
	{
		case -1:
			return false;
		case 4:
			return (jjockCount >= 2);
		case 5:
			return (panCount >= 1);
		default:
			return [player isEatCardOK:cards[0].m_idx] && [player isEatCardOK:cards[1].m_idx] && [player isEatCardOK:cards[2].m_idx];
	}

	return false;
}

@end
