#import "GoStopAppDelegate.h"
#import "TeamLogoView.h"
#import "ViewManager.h"
#import "ToDoManager.h"
#import "PlayerManager.h"
#import "GameRuleManager.h"
#import "AiManager.h"

@implementation GoStopAppDelegate

@synthesize window;
@synthesize viewController;

- (void)applicationDidFinishLaunching:(UIApplication *)application {
	srand(time(NULL));
	[ViewManager initManager:window:viewController];
	[GameRuleManager initManager];
	[PlayerManager initManager];
	[ToDoManager initManager];
	[AiManager initManager];
	[[ViewManager getInstance] changeView:@"TeamLogoView"];

    [[UIAccelerometer sharedAccelerometer] setUpdateInterval:(1.0 / 40)];
    [[UIAccelerometer sharedAccelerometer] setDelegate:self];
}

- (void)dealloc {
	[[AiManager getInstance] closeManager];
	[[ViewManager getInstance] closeManager];
	[[ToDoManager getInstance] closeManager];
	[[PlayerManager getInstance] closeManager];
	[[GameRuleManager getInstance] closeManager];
    [window release];
	[super dealloc];
}

- (void)accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration {
	[[[ViewManager getInstance] getCurView] myAccelerometer:accelerometer didAccelerate:acceleration];
}

@end
