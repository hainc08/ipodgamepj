//
//  GoStopAppDelegate.h
//  GoStop
//
//  Created by Sasin on 08. 10. 15.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GoStopViewController;

@interface GoStopAppDelegate : NSObject <UIAccelerometerDelegate> {
	IBOutlet UIWindow *window;
	IBOutlet GoStopViewController *viewController;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) GoStopViewController *viewController;

@end

