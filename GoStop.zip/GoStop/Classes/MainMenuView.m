#import "MainMenuView.h"
#import "ViewManager.h"
#import "PlayerManager.h"
#import "GameRuleManager.h"

@implementation MainMenuView

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	//다음뷰로 이동 한다. - 여기는 단순한 화면터치...
}

- (void)reset:(NSObject*)param
{
	[menuWnd setAlpha:1];
	[ruleWnd setAlpha:0];
	[infoWnd setAlpha:0];
}

- (BOOL)textFieldShouldReturn:(UITextField *)theTextField {
	[theTextField resignFirstResponder];
	return YES;
}

- (void)fillPlayerInfo
{
	int ManWin = [[PlayerManager getInstance] getRecord:10];
	int CpuWin = [[PlayerManager getInstance] getRecord:0];
	
	int ManMaxScore = [[PlayerManager getInstance] getRecord:11];
	int CpuMaxScore = [[PlayerManager getInstance] getRecord:1];
	
	int ManMaxGo = [[PlayerManager getInstance] getRecord:12];
	int CpuMaxGo = [[PlayerManager getInstance] getRecord:2];
	
	float ManWinPer;
	float CpuWinPer;
	
	if ((ManWin + CpuWin) == 0)
	{
		ManWinPer = CpuWinPer = 0;
	}
	else
	{
		ManWinPer = (float)ManWin/(float)(ManWin + CpuWin) * 100;
		CpuWinPer = (float)CpuWin/(float)(ManWin + CpuWin) * 100;
	}
	
	NSString* infoStr1 = [NSString stringWithFormat:@"%d\n%d\n%d\n(%.1f%%)", ManMaxScore, ManMaxGo, ManWin, ManWinPer];
	NSString* infoStr2 = [NSString stringWithFormat:@"%d\n%d\n%d\n(%.1f%%)", CpuMaxScore, CpuMaxGo, CpuWin, CpuWinPer];
	[infoLabel1 setText: infoStr1];
	[infoLabel2 setText: infoStr2];
}

- (IBAction)ButtonClick:(id)sender
{
	if (sender == MoreApps)
	{
		[[ViewManager getInstance] changeView:@"MoreApps"];
	}
	else if (sender == resetMoneyButton)
	{
		[[PlayerManager getInstance] setMoney:1000000];
		NSString* text = [NSString stringWithFormat:@"%lld원", [PlayerManager getInstance].money];
		[playerMoney setText:text];
	}
	else if (sender == resetInfoButton)
	{
		[[PlayerManager getInstance] resetInfo];
		[self fillPlayerInfo];
	}
	else if (sender == NewGame)
	{
		[[ViewManager getInstance] changeView:@"GameView"];
	}
	else if (sender == GameRule)
	{
		[menuWnd setAlpha:0];
		[ruleWnd setAlpha:1];
		[nanDouble setOn:[GameRuleManager getInstance].nanDouble];
		[jabbuck setOn:[GameRuleManager getInstance].jabbuck];
		[nagari setOn:[GameRuleManager getInstance].nagari];
		[goBak setOn:[GameRuleManager getInstance].goBak];
		[mission setOn:[GameRuleManager getInstance].mission];
		[showAll setOn:[GameRuleManager getInstance].showAll];
		[ggang setOn:[GameRuleManager getInstance].ggang];
	}
	else if (sender == PlayerInfo)
	{
		[playerName setText:[PlayerManager getInstance].playerName];
		NSString* text = [NSString stringWithFormat:@"%lld원", [PlayerManager getInstance].money];
		[playerMoney setText:text];
		[menuWnd setAlpha:0];
		[infoWnd setAlpha:1];
		
		[self fillPlayerInfo];
	}
	else if (sender == CreaditButton)
	{
		[[ViewManager getInstance] changeView:@"CreaditView"];
	}	
	else if (sender == infoOkButton)
	{
		[[PlayerManager getInstance] setPlayerName:playerName.text];
		[[PlayerManager getInstance] saveToFile];
		[menuWnd setAlpha:1];
		[infoWnd setAlpha:0];
	}
	else if (sender == ruleOKButton)
	{
		[[GameRuleManager getInstance] setNanDouble:[nanDouble isOn]];
		[[GameRuleManager getInstance] setJabbuck:[jabbuck isOn]];
		[[GameRuleManager getInstance] setNagari:[nagari isOn]];
		[[GameRuleManager getInstance] setGoBak:[goBak isOn]];
		[[GameRuleManager getInstance] setMission:[mission isOn]];
		[[GameRuleManager getInstance] setShowAll:[showAll isOn]];
		[[GameRuleManager getInstance] setGgang:[ggang isOn]];
		[[PlayerManager getInstance] saveToFile];
		[menuWnd setAlpha:1];
		[ruleWnd setAlpha:0];
	}
	else if (sender == ruleCancelButton)
	{
		[menuWnd setAlpha:1];
		[ruleWnd setAlpha:0];
	}
}

@end
