#import <UIKit/UIKit.h>
#import "BaseView.h"

@interface MainMenuView : BaseView {
    IBOutlet id NewGame;
    IBOutlet id PlayerInfo;
    IBOutlet id GameRule;
    IBOutlet id CreaditButton;
    IBOutlet id resetMoneyButton;

    IBOutlet UISwitch *nanDouble;
    IBOutlet UISwitch *jabbuck;
    IBOutlet UISwitch *nagari;
    IBOutlet UISwitch *goBak;
    IBOutlet UISwitch *mission;
    IBOutlet UISwitch *showAll;
    IBOutlet UISwitch *ggang;

    IBOutlet id MoreApps;
	
    IBOutlet id ruleOKButton;
    IBOutlet id ruleCancelButton;
    IBOutlet id infoOkButton;
    IBOutlet id resetInfoButton;

    IBOutlet id ruleWnd;
    IBOutlet id menuWnd;
    IBOutlet id infoWnd;
    IBOutlet id infoLabel1;
    IBOutlet id infoLabel2;

    IBOutlet UITextField *playerName;
    IBOutlet UITextField *playerMoney;
}

- (IBAction)ButtonClick:(id)sender;
- (void)fillPlayerInfo;

@end
