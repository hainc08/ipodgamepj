#import "TeamLogoView.h"
#import "ViewManager.h"

@implementation TeamLogoView

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	if ( step == 1 )
	{
		if (rand()%10 == 0) [logoSound play];
		step=2;
	}
}

- (void)reset:(NSObject*)param
{
	[super reset:param];
	[TeamLogoImg setAlpha:0.f];
	step = 0;

    NSBundle *mainBundle = [NSBundle mainBundle];
	logoSound = [[SoundEffect alloc] initWithContentsOfFile:[mainBundle pathForResource:@"oink" ofType:@"wav"]];
}

- (void)dealloc
{
    [logoSound release];
    [super dealloc];
}

- (void)update
{
	[super update];

	switch (step)
	{
		case 0:
			alpha = 0.f;
			if (frameTick > 5) step = 1;
			break;
		case 1:
			alpha += 0.1f;
			if (alpha > 1.0f) alpha = 1.0f;
			break;
		case 2:
			alpha -= 0.1f;
			if (alpha <= 0.f) step = 3;
			break;
		case 3:
			//다음뷰로 이동 한다.
			[[ViewManager getInstance] changeView:@"GameLogoView"];
			break;
	}

	[TeamLogoImg setAlpha:alpha];
}

@end
