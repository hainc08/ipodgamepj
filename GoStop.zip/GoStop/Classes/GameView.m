#import "GameView.h"
#import "ViewManager.h"
#import "../BaseClasses/ToDoManager.h"
#import "../BaseClasses/GameRuleManager.h"
#import "../BaseClasses/PlayerManager.h"
#import "../BaseClasses/AiManager.h"

@implementation GameView

- (id)initWithCoder:(NSCoder *)coder {
	self = [super initWithCoder:coder];
	cardInit = false;
	return self;
}

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	cardInit = false;
	return self;
}

- (void)changePhase:(int)phase
{
	phaseTraking[trakingIdx] = phase;
	turnPhase = phase;	
	++trakingIdx;
}

- (void)reset:(NSObject*)param
{
	[self setUpGameBoard];		

	[flashMsg setAlpha:0];

	[super reset:param];
	[goStopView setAlpha:0];
	[goImg setAlpha:0];
	[gameOverView setAlpha:0];

	[missionComplete setAlpha:0];
	[missionFail setAlpha:0];
	[x2 setAlpha:0];
	[x3 setAlpha:0];
	
	[manScore setText:[NSString stringWithFormat:@"Score : 0 - Money : %lld", [PlayerManager getInstance].money]];	
	[cpuScore setText:@"Score : 0"];
	[playerName setText:[PlayerManager getInstance].playerName];
	[self sendSubviewToBack:backImg];	

	nagariDouble = 1;
	nagariCount = 0;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	if (![[ToDoManager getInstance] isMoveOver]) return;
	int count = [touches count];
	UITouch *touch;
	NSEnumerator *touchEnum = [touches objectEnumerator];
	
	if (count == 1)
	{
		touch = [touchEnum nextObject];
		CGPoint pos = [touch locationInView: playerHand];
		
		if (turnPhase == 0)
		{
			if (pos.y > 0)
			{
				if ([MAN isHandCardOK:(pos.x / 32)])
				{
					[MAN resetEable];
					[self turnPlay:MAN:[MAN getFromHand:(pos.x / 32)]:[self getCard]];
					if (turnPhase != 12) [self changePhase:1];
					return;
				}
			}
			else if (MAN.m_bombedCardCount > 0)
			{
				pos = [touch locationInView: cardDeck];
				if ((pos.x > 0) && (pos.y > 0))
				{
					if ((pos.x < 45) && (pos.y < 65))
					{
						[MAN setM_bombedCardCount:MAN.m_bombedCardCount - 1];
						[self turnPlay:MAN:NULL:[self getCard]];
						if (turnPhase != 12) [self changePhase:1];
						return;
					}
				}
			}
		}
		else if (turnPhase == 12)
		{
			pos = [touch locationInView: self];
			if ((pos.y > 180)&&(pos.y < 300))
			{
				if (pos.x < 160)
				{
					[self eatCard:MAN:selectCardMark:0];
					groundCard[selectCardMark][0] = groundCard[selectCardMark][1];
				}
				else
				{
					[self eatCard:MAN:selectCardMark:1];
				}
				
				groundCard[selectCardMark][1] = NULL;
				[[ToDoManager getInstance] addCardMove:groundCard[selectCardMark][0] pos:groundPos[selectCardMark] isAni:true isZoom:false isShow:true waitNext:1];

				[self changePhase:1];
				if (reserveCard != NULL)
				{
					[self eatFromGround:MAN:reserveCard];
					reserveCard = NULL;
				}
			}
		}
	}

	[MAN handCardZoom:-1];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	if (![[ToDoManager getInstance] isMoveOver]) return;

	int count = [touches count];
	UITouch *touch;
	NSEnumerator *touchEnum = [touches objectEnumerator];
	
	if (count == 1)
	{
		touch = [touchEnum nextObject];
		CGPoint pos = [touch locationInView: playerHand];

		if (turnPhase == 0)
		{
			if (pos.y > 0)
				[ground bringSubviewToFront:[MAN handCardZoom:(pos.x / 32)]];
		}
	}
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	if (![[ToDoManager getInstance] isMoveOver]) return;

	int count = [touches count];
	UITouch *touch;
	NSEnumerator *touchEnum = [touches objectEnumerator];
	
	if (count == 1)
	{
		touch = [touchEnum nextObject];
		CGPoint pos = [touch locationInView: playerHand];

		if (turnPhase == 0)
		{
			if (pos.y > 0)
			{
				selectIdx = pos.x / 32;
				[ground bringSubviewToFront:[MAN handCardZoom:selectIdx]];
			}
		}
	}
}

- (void)setUpGameBoard;
{
	[self changePhase:-1];
	turnCount = 1;
	trakingIdx = 0;
	ggang = 0;
	
	if (cardInit == false)
	{
		NSBundle *mainBundle = [NSBundle mainBundle];
		jjockSound = [[SoundEffect alloc] initWithContentsOfFile:[mainBundle pathForResource:@"jjock" ofType:@"wav"]];
		goSound = [[SoundEffect alloc] initWithContentsOfFile:[mainBundle pathForResource:@"go" ofType:@"wav"]];
		stopSound = [[SoundEffect alloc] initWithContentsOfFile:[mainBundle pathForResource:@"stop" ofType:@"wav"]];
		
		groundPos[0] = CGPointMake(40, 190);
		groundPos[1] = CGPointMake(110, 190);
		groundPos[2] = CGPointMake(200, 190);
		groundPos[3] = CGPointMake(270, 190);
		groundPos[4] = CGPointMake(30, 240);
		groundPos[5] = CGPointMake(100, 240);
		groundPos[6] = CGPointMake(210, 240);
		groundPos[7] = CGPointMake(280, 240);
		groundPos[8] = CGPointMake(40, 290);
		groundPos[9] = CGPointMake(110, 290);
		groundPos[10] = CGPointMake(200, 290);
		groundPos[11] = CGPointMake(270, 290);
	
		ground = (BlankView*)([[ViewManager getInstance] getInstView:@"BlankView"]);
		[[ToDoManager getInstance] setGround:ground];
		[ground setPosSize:[self center]:@"FullSize"];
		[self addSubview:ground];
		[self sendSubviewToBack:ground];

		for (int i=0; i<48; ++i)
		{
			cards[i] = (Card*)([[ViewManager getInstance] getInstView:@"Card"]);
			[cards[i] setCard:i];
			[ground addSubview:cards[i]];
		}
		
		cardInit = true;

		CPU  = [Player alloc];
		MAN  = [Player alloc];
		[[AiManager getInstance] setPlayer:CPU:MAN];
		for (int i=0; i<12; ++i)
		{
			[[AiManager getInstance] setGroundCard:&groundCard[i] mark:i];
		}
		
		mission = (Mission*)([[ViewManager getInstance] getInstView:@"Mission"]);
		[mission init];
		[self addSubview:mission];
		[mission setCenter:CGPointMake(160, 240)];
		[self bringSubviewToFront:mission];
		[mission setAlpha:0];
	}
	else
	{
		[manScore setText:[NSString stringWithFormat:@"Score : 0 - Money : %lld", [PlayerManager getInstance].money]];	
		[cpuScore setText:@"Score : 0"];
	}

	for (int i=0; i<48; ++i)
	{
		deck[i] = cards[i];
		[deck[i] setIsBomb:false];
		[deck[i] setShow:false];
		groundCard[i/4][i%4] = NULL;
	}

	[CPU resetPLayer:true];
	[MAN resetPLayer:false];
	
	if ([GameRuleManager getInstance].mission && (rand()%5 == 0))
	{
		[mission setMission:rand()%6];
		[mission setAlpha:1];
	}
	else
	{
		[mission setMission:-1];
		[mission setAlpha:0];
	}
	
	[mission setPanCount:0];
	[mission setJjockCount:0];

	Card *card;
	//패를 섞는다.
	for (int i=0; i<100; ++i)
	{
		int c1 = rand() % 48;
		int c2 = rand() % 48;
		
		card = deck[c1];
		deck[c1] = deck[c2];
		deck[c2] = card;
	}
	
	deckCount = 48;
	
	for (int i=0; i<48; ++i)
	{
		[deck[i] setCenter:CGPointMake(0, 0)];
		//늘어놔보기...
		//cards[i].transform = CGAffineTransformMake(0.1, 0.0, 0.0, 0.1, (i % 8) * 40 + 20, (i / 8) * 50 + 50);
		[[ToDoManager getInstance] addCardMove:deck[i] pos:CGPointMake(160, 240) isAni:false isZoom:false isShow:false waitNext:0];
	}

	for (int i=0; i<10; ++i)
		[MAN giveToHand:[self getCard]];
	for (int i=0; i<10; ++i)
		[CPU giveToHand:[self getCard]];

	groundCount = 0;
		
	for (int i=0; i<8; ++i)
	{
		[self giveToGround:[self getCard]:false];
	}

	for (int i=0; i<12; ++i)
	{
		jabbuck[i] = NULL;
	}

	[MAN sortCard];
}

- (void)giveToGround:(Card *)card:(bool)withSound{
	if (card == NULL) return;

	int mark = [card getMark];
	groundCard[mark][[self hitToGround:card withSound:withSound]] = card;
	++groundCount;
}

- (int)hitToGround:(Card *)card withSound:(bool)sound
{
	int mark = [card getMark];
	CGPoint pos = groundPos[mark];
	int i;

	for (i=0; i<3; ++i)
	{
		if (groundCard[mark][i] == NULL) break;
		pos.x += 8;
	}

	if (sound && i>0)
	{
		[[ToDoManager getInstance] addCardMoveWithSound:card pos:pos isAni:true isZoom:false isShow:true waitNext:1];
	}
	else
	{
		[[ToDoManager getInstance] addCardMove:card pos:pos isAni:true isZoom:false isShow:true waitNext:1];
	}
	
	return i;
}

- (bool)eatFromGround:(Player*)player:(Card *)card
{
	int mark = [card getMark];
	
	if (groundCard[mark][0] == NULL)
	{
		[self giveToGround:card:false];
	}
	else
	{
		[player giveToEat:card];

		if (groundCard[mark][2] != NULL)
		{
			//세장있으면 다 먹고...
			[self eatCard:player:mark:2];
			[self eatCard:player:mark:1];
			[self eatCard:player:mark:0];

			if ([GameRuleManager getInstance].jabbuck && jabbuck[mark] == player)
				[self getPlayer2Pi:player];
			else
				[self getPlayerPi:player];
		}
		else if (groundCard[mark][1] != NULL)
		{
			//두장있으면 골라서 한장만...
			if (player == MAN)
			{
				//같은 패이면 걍 1번을 먹어가자...
				if ([groundCard[mark][1] cardType] == [groundCard[mark][0] cardType])
				{
					[self eatCard:player:mark:1];
				}
				else
				{
					[[ToDoManager getInstance] addCardMove:groundCard[mark][0] pos:CGPointMake(80, 240) isAni:true isZoom:true isShow:true waitNext:0];
					[[ToDoManager getInstance] addCardMove:groundCard[mark][1] pos:CGPointMake(240, 240) isAni:true isZoom:true isShow:true waitNext:10];
					selectCardMark = mark;
					[self changePhase:12];
					return false;
				}
			}
			else
			{				
				float weight1 = [[AiManager getInstance] getCardWeight:groundCard[mark][0]];
				float weight2 = [[AiManager getInstance] getCardWeight:groundCard[mark][1]];

				if (weight1 > weight2)
				{
					[self eatCard:player:mark:0];
	
					groundCard[mark][0] = groundCard[mark][1];
					groundCard[mark][1] = NULL;

					[[ToDoManager getInstance] addCardMove:groundCard[mark][0] pos:groundPos[mark] isAni:true isZoom:false isShow:true waitNext:1];
				}
				else
				{
					[self eatCard:player:mark:1];
					groundCard[mark][1] = NULL;					
				}
			}
		}
		else
		{
			//한장있으면 걍...
			[self eatCard:player:mark:0];
		}
	}

	return true;
}

- (void)eatCard:(Player*)player:(int)mark:(int)idx
{
	[player giveToEat:groundCard[mark][idx]];
	groundCard[mark][idx] = NULL;	
}

- (void)turnPlay:(Player*)player:(Card *)card1:(Card *)card2
{
	Card* bombCard2 = NULL;
	Card* bombCard3 = NULL;

	if ((card1 != NULL)&&(card1.isBomb))
	{
		int mark = [card1 getMark];

		[player setShakeCount:player.shakeCount + 1];
		bombCard2 = [player getFromHand_Mark:mark];
		bombCard3 = [player getFromHand_Mark:mark];
		[[ToDoManager getInstance] cardShake:card1:bombCard2:bombCard3];
	}
	
	if (card1 == NULL)
	{
		[self hitToGround:card2 withSound:true];
		
		[[ToDoManager getInstance] addDelay:3];
		
		[self eatFromGround:player:card2];
		reserveCard = NULL;
	}
	else if ([card1 getMark] == [card2 getMark])
	{
		int mark = [card1 getMark];

		if (bombCard2 != NULL)
		{
			[[ToDoManager getInstance] addCardShow:bombCard2 isShow:(player == MAN) waitNext:0];
			[[ToDoManager getInstance] addCardShow:bombCard3 isShow:(player == MAN) waitNext:0];
			
			[player removeBomb:mark];
			[player giveToHand:bombCard2];
			[player giveToHand:bombCard3];
		}

		[self giveToGround:card1:(groundCard[mark][0] != NULL)];
		[self giveToGround:card2:true];
		
		[[ToDoManager getInstance] addDelay:3];

		if (groundCard[mark][3] != NULL)
		{
			//동시패션...
			[self eatCard:player:mark:3];
			[self eatCard:player:mark:2];
			[self eatCard:player:mark:1];
			[self eatCard:player:mark:0];
			
			[self getPlayerPi:player];	
		}
		else if (groundCard[mark][2] != NULL)
		{
			//쌌다!
			jabbuck[mark] = player;
			if (turnCount == 1) [self getPlayerPi:player];
		}
		else if (groundCard[mark][1] != NULL)
		{
			//쪽!			
			[self eatCard:player:mark:1];
			[self eatCard:player:mark:0];

			[jjockSound play];
			[self getPlayerPi:player];
			if (player == MAN) [mission setJjockCount:mission.jjockCount + 1];
		}
	}
	else
	{
		if (card1.isBomb)
		{
			int mark = [card1 getMark];
			if (groundCard[mark][0] != NULL)
			{
				//폭탄을 터쳐라!
				[self giveToGround:bombCard2:true];
				[self giveToGround:bombCard3:true];
				[player setM_bombedCardCount:player.m_bombedCardCount + 2];
			}
			else
			{
				[[ToDoManager getInstance] addCardShow:bombCard2 isShow:(player == MAN) waitNext:0];
				[[ToDoManager getInstance] addCardShow:bombCard3 isShow:(player == MAN) waitNext:1];

				[player removeBomb:mark];
				[player giveToHand:bombCard2];
				[player giveToHand:bombCard3];
			}
		}
		
		[self hitToGround:card1 withSound:true];
		[self hitToGround:card2 withSound:true];
		
		[[ToDoManager getInstance] addDelay:3];

		if([self eatFromGround:player:card1])
		{
			[self eatFromGround:player:card2];
			reserveCard = NULL;
		}
		else
		{
			reserveCard = card2;
		}
	}
	
	//판쓰리 체크...
	bool allEat = true;
	for (int i=0; i<12; ++i)
	{
		allEat &= (groundCard[i][0] == NULL);
	}
	
	if (allEat)
	{
		if (turnCount < 10)
		{
			[self getPlayerPi:player];
			if (player == MAN) [mission setPanCount:mission.panCount + 1];
		}
	}
}

- (void)addBonusText:(NSString*)str go:(bool)isGo
{
	id textLabel;
	switch (bonusCount)
	{
		case 0:
			if (isGo) textLabel = bonusText1_2;
			else textLabel = bonusText1;
			break;
		case 1:
			if (isGo) textLabel = bonusText2_2;
			else textLabel = bonusText2;
			break;
		case 2:
			if (isGo) textLabel = bonusText3_2;
			else textLabel = bonusText3;
			break;
	}

	[textLabel setAlpha:1];	
	[textLabel setText:str];
	++bonusCount;
}

- (int)FillScoreInfo:(Player*)winner go:(bool)isGo
{
	int finalPoint;
	
	bonusCount = 0;
	id scoreTextId;
	id pointTextId;
	
	if (isGo)
	{
		[bonusText1_2 setAlpha:0];
		[bonusText2_2 setAlpha:0];
		[bonusText3_2 setAlpha:0];
		scoreTextId = scoreText_2;
		pointTextId = pointText_2;
	}
	else
	{
		[bonusText1 setAlpha:0];
		[bonusText2 setAlpha:0];
		[bonusText3 setAlpha:0];
		scoreTextId = scoreText;
		pointTextId = pointText;
	}
	
	Player* loser;
	if (winner == MAN) loser = CPU;
	else loser = MAN;

	[scoreTextId setAlpha:1];
	finalPoint = winner.score;
	[scoreTextId setText:[NSString stringWithFormat:@"Score : %d", finalPoint]];
	
	finalPoint += winner.goCount;
	if (winner.goCount >= 3)
	{
		finalPoint *= 2;
		[self addBonusText:[NSString stringWithFormat:@"%d Go : +%d, x2", winner.goCount, winner.goCount] go:isGo];
	}
	else if (winner.goCount > 0)
	{
		[self addBonusText:[NSString stringWithFormat:@"%d Go : +%d", winner.goCount, winner.goCount] go:isGo];
	}
	
	if (winner.shakeCount > 0)
	{
		int kt = 1;
		for (int k=0; k<winner.shakeCount; ++k)
		{
			kt *= 2;
		}
		
		finalPoint *= kt;
		[self addBonusText:[NSString stringWithFormat:@"흔들기 : %d회, x%d", winner.shakeCount, kt] go:isGo];
	}

	//광박 피박 계산...
	NSString* bonus = @"";
	if ([winner getCardCount:0] >= 3)
	{
		if ([loser getCardCount:0] == 0)
		{
			bonus = @"광박 x2";
			finalPoint *= 2;
		}
	}
	
	if ([winner getCardCount:3]+[winner getCardCount:4]*2 >= 10)
	{
		int loserPiCount = [loser getCardCount:3]+[loser getCardCount:4]*2;
		if ((loserPiCount > 0) && (loserPiCount < 6))
		{
			if (bonus == @"광박 x2") bonus = @"광박 x2, 피박 x2";
			else bonus = @"피박 x2";
			finalPoint *= 2;
		}
	}
	
	if (loser.goCount > 0)
	{
		if (bonus == @"광박 x2") bonus = @"광박 x2, 고박 x 2";
		if (bonus == @"광박 x2, 피박 x2") bonus = @"광박 x2, 피박 x2, 고박 x 2";
		else bonus = @"고박 x2";
		finalPoint *= 2;
	}
	
	[self addBonusText:bonus go:isGo];
	
	if (nagariDouble != 1)
	{
		[self addBonusText:[NSString stringWithFormat:@"%d회 나가리 : x%d", nagariCount, nagariDouble] go:isGo];
		finalPoint *= nagariDouble;
	}
	
	[pointTextId setText:[NSString stringWithFormat:@"Final : %d", finalPoint]];
	
	return finalPoint;
}

- (void)GameOver:(Player*)winner
{
	int finalPoint;
	int recordOffset;
	bool success = false;
	
	if (winner != NULL)
	{
		if (winner == MAN)
		{
			[winnerText setText:@"YOU WIN"];
			recordOffset = 10;
			if (mission.missionIdx != -1)
			{
				success = [mission checkMission:winner];
				
				if (success)
				{
					[missionComplete setAlpha:1];
					[missionFail setAlpha:0];
					if (mission.missionIdx == 4) [x3 setAlpha:1];
					else [x2 setAlpha:1];
				}
				else
				{
					[missionComplete setAlpha:0];
					[missionFail setAlpha:1];
					[x2 setAlpha:0];
					[x3 setAlpha:0];
				}
			}
		}
		else
		{
			[winnerText setText:@"CPU WIN"];
			recordOffset = 0;
			[missionComplete setAlpha:0];
			[missionFail setAlpha:0];
			[x2 setAlpha:0];
			[x3 setAlpha:0];
		}

		finalPoint = [self FillScoreInfo:winner go:false];
		if (success)
		{
			if (mission.missionIdx == 4) finalPoint *= 3;
			else finalPoint *= 2;
			[pointText setText:[NSString stringWithFormat:@"Final : %d", finalPoint]];
		}

		[[PlayerManager getInstance] setRecordMax:recordOffset+1 value:finalPoint];
		if (winner == CPU) finalPoint *= -1;
		[[PlayerManager getInstance] setRecordMax:recordOffset+2 value:winner.goCount];
		[[PlayerManager getInstance] setRecordAdd:recordOffset value:1];
	}
	else
	{
		//draw...
		finalPoint = 0;
		[winnerText setText:@"DRAW GAME"];	
		[scoreText setAlpha:0];
		[pointText setAlpha:0];

		[bonusText1 setAlpha:0];
		[bonusText2 setAlpha:0];
		[bonusText3 setAlpha:0];
		
		if ([GameRuleManager getInstance].nagari)
		{
			bonusCount = 0;
			[self addBonusText:[NSString stringWithFormat:@"%d회 나가리 : 다음판 x%d", nagariCount+1, nagariDouble*2] go:false];
		}
	}

	if (finalPoint < 0)
	{
		[finalMoney setText:[NSString stringWithFormat:@"%lld - %d = %lld",
			[PlayerManager getInstance].money, finalPoint * -100, [PlayerManager getInstance].money + finalPoint * 100]];
	}
	else
	{
		[finalMoney setText:[NSString stringWithFormat:@"%lld + %d = %lld",
			[PlayerManager getInstance].money, finalPoint * 100, [PlayerManager getInstance].money + finalPoint * 100]];
	}

	[[PlayerManager getInstance] addMoney: finalPoint * 100];
	
	[gameOverView setAlpha:1];
	[manScore setText:[NSString stringWithFormat:@"Score : %d - Money : %lld", MAN.score, [PlayerManager getInstance].money]];
	[[PlayerManager getInstance] saveToFile];

	if ([GameRuleManager getInstance].nagari)
	{
		if (winner == NULL)
		{
			nagariDouble *= 2;
			++nagariCount;
		}
		else
		{
			nagariDouble = 1;
			nagariCount = 0;
		}
	}

	[self changePhase:-2];
}

- (Card *)getCard {
	Card *card;

	if (deckCount == 0) return NULL;
	--deckCount;
	card = deck[deckCount];
	deck[deckCount] = NULL;
	
	return card;
}

- (void)dealloc {
	for (int i=0; i<48; ++i)
	{
		[cards[i] dealloc];
	}
	[super dealloc];
}

- (void)myAccelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration
{
	if (![GameRuleManager getInstance].ggang) return;
	if (turnPhase < 0) return;
	if (nagariCount > 2) return;

	if (acceleration.x > 2)
	{
		++ggang;
		if (ggang > 10)
		{
			ggang = 0;
			[self GameOver:NULL];			
		}
	}
}
			
- (IBAction)ButtonClick:(id)sender
{
	if (sender == gotoMainButton)
	{
		[[ViewManager getInstance] changeView:@"MainMenuView"];
	}
	else if (sender == testButton)
	{
		[self GameOver:NULL];
	}
	if (sender == goButton)
	{
		[goSound play];
		[MAN go];

		[self goShow:MAN.goCount];
		[goStopView setAlpha:0];
		[self changePhase:11];
		goTick = frameTick;
	}
	else if (sender == stopButton)
	{
		[stopSound play];
		[goStopView setAlpha:0];
		[self GameOver:MAN];		
	}
	else if (sender == okButton)
	{
		[gameOverView setAlpha:0];
		[missionComplete setAlpha:0];
		[missionFail setAlpha:0];
		[x2 setAlpha:0];		
		[x3 setAlpha:0];		
		[self setUpGameBoard];
	}
}

- (void)update
{
	[[ToDoManager getInstance] update];
	
	if ([[ToDoManager getInstance] isMoveOver])
	{
		switch (turnPhase)
		{
			case -1:
				[self changePhase:0];
				for (int i=0; i<12; ++i)
				{
					if (groundCard[i][0] != NULL) [MAN checkEable:i];
				}
				[mission setAlpha:0];
				break;
			case 1:
				ggang = 0;
				[MAN setScore:[[GameRuleManager getInstance] getScore:MAN]];
				[manScore setText:[NSString stringWithFormat:@"Score : %d - Money : %lld", MAN.score, [PlayerManager getInstance].money]];
				if (MAN.score > MAN.goScore)
				{
					if ((CPU.goCount != 0) || (turnCount == 10))
					{
						[self GameOver:MAN];
						break;
					}
					
					[self FillScoreInfo:MAN go:true];					
					[goStopView setAlpha:1];
					//Go Stop여부확인
					[self changePhase:10];
					break;
				}
					
				if (CPU.m_handCardCount > 0)
				{
					int cardIdx = [[AiManager getInstance] getNextCardIdx];
					[self turnPlay:CPU:[CPU getFromHand:cardIdx]:[self getCard]];
				}
				else if (CPU.m_bombedCardCount > 0)
				{
					[CPU setM_bombedCardCount:CPU.m_bombedCardCount - 1];
					[self turnPlay:CPU:NULL:[self getCard]];
				}
						
				[self changePhase:2];
				break;
			case 11:
				if (goTick + 10 == frameTick)
				{
					[self goHide];

					int cardIdx = [[AiManager getInstance] getNextCardIdx];
					[self turnPlay:CPU:[CPU getFromHand:cardIdx]:[self getCard]];
					
					[self changePhase:2];
				}
				break;
			case 21:
				if (goTick + 10 < frameTick)
				{
					[self goHide];					
					[self changePhase:0];
				}
				break;
			case 2:
				[CPU setScore:[[GameRuleManager getInstance] getScore:CPU]];
				[cpuScore setText:[NSString stringWithFormat:@"Score : %d", CPU.score]];
				if (CPU.score > CPU.goScore)
				{
					if ((MAN.goCount != 0) || (turnCount == 10))
					{
						[self GameOver:CPU];
						break;	
					}

					//Go Stop여부결정
					if ([[AiManager getInstance] GoOrStop])
					{
						[goSound play];
						[CPU go];

						[self goShow:CPU.goCount];
						[goStopView setAlpha:0];
						[self changePhase:21];
						goTick = frameTick;
						++turnCount;
					}
					else
					{
						[stopSound play];
						[self GameOver:CPU];
					}
					break;
				}
				
				for (int i=0; i<12; ++i)
				{
					if (groundCard[i][0] != NULL) [MAN checkEable:i];
				}

				if (deckCount == 0)
				{
					[self GameOver:NULL];
					break;
				}

				[self changePhase:0];
				++turnCount;
				break;
		}
	}
	
	[super update];
}

- (void)goShow:(int)go
{
	[goImg setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%dgo.png", go]]];
	[goImg setTransform:CGAffineTransformMake(3, 0.0, 0.0, 3, 0, 0)];
	[goImg setAlpha:0];
	
	[UIView beginAnimations:@"goShow" context:NULL];
	[UIView setAnimationDuration:0.2];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	[goImg setTransform:CGAffineTransformMake(1, 0.0, 0.0, 1, 0, 0)];
	[goImg setAlpha:1];
	[UIView commitAnimations];	
}

- (void)goHide
{
	[UIView beginAnimations:@"goShow" context:NULL];
	[UIView setAnimationDuration:0.2];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	[goImg setTransform:CGAffineTransformMake(3, 0.0, 0.0, 3, 0, 0)];
	[goImg setAlpha:0];
	[UIView commitAnimations];
}

- (void)showFlashMsg:(NSString*)msg
{
	[flashMsg setText:msg];
	[flashMsg setAlpha:1];

	[UIView beginAnimations:@"flashMsg" context:NULL];
	[UIView setAnimationDuration:2.0];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseIn];
	[flashMsg setAlpha:0];
	[UIView commitAnimations];	
}

- (void)getPlayerPi:(Player*)player
{
	if (turnCount == 1)
	{
		int amount;
		NSString* msg;
		if (player == MAN)
		{
			amount = 300;
			msg = @"+300";
		}
		else
		{
			amount = -300;
			msg = @"-300";
		}

		[[PlayerManager getInstance] addMoney:amount];
		[self showFlashMsg:msg];
		return;
	}
	
	if (turnCount == 10) return;

	Card* card;
	if (player == MAN) card = [CPU getPiCard];
	else  card = [MAN getPiCard];
	
	if (card) [player giveToEat:card];

	[CPU setScore:[[GameRuleManager getInstance] getScore:CPU]];
	[MAN setScore:[[GameRuleManager getInstance] getScore:MAN]];
	
	[cpuScore setText:[NSString stringWithFormat:@"Score : %d", CPU.score]];
	[manScore setText:[NSString stringWithFormat:@"Score : %d - Money : %lld", MAN.score, [PlayerManager getInstance].money]];
}

- (void)getPlayer2Pi:(Player*)player
{
	if (turnCount == 10) return;
	
	Card* card;
	Player* other;
	if (player == MAN) other = CPU;
	else other = MAN;

	if ([other getCardCount:3] > 1)
	{
		card = [other getPiCard];
		[player giveToEat:card];	
		card = [other getPiCard];
		[player giveToEat:card];	
	}
	else if ([other getCardCount:4] > 0)
	{
		card = [other get2PiCard];
		[player giveToEat:card];	
	}
	else
	{
		card = [other getPiCard];
		if (card) [player giveToEat:card];	
	}
	
	[CPU setScore:[[GameRuleManager getInstance] getScore:CPU]];
	[MAN setScore:[[GameRuleManager getInstance] getScore:MAN]];
	
	[cpuScore setText:[NSString stringWithFormat:@"Score : %d", CPU.score]];
	[manScore setText:[NSString stringWithFormat:@"Score : %d - Money : %lld", MAN.score, [PlayerManager getInstance].money]];	
}

@end
