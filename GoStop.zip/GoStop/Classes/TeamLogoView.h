#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "BaseView.h"
#import "SoundEffect.h" 

@interface TeamLogoView : BaseView {
    IBOutlet id TeamLogoImg;
	int step;
	float alpha;	
    SoundEffect *logoSound;
}

@end

