#import <UIKit/UIKit.h>
#import "BaseView.h"

@interface CreaditView : BaseView {
    IBOutlet id MainMenuButton;

    IBOutlet id TeamLogo;
    IBOutlet id ProgramImg;
    IBOutlet id ArtImg;
    IBOutlet id DirectImg;
	
    IBOutlet id creaditText1;
    IBOutlet id creaditText2;
    IBOutlet id creaditText3;
    IBOutlet id creaditText4;
    IBOutlet id creaditText5;
	
	int creaditTextIdx;
}

- (IBAction)ButtonClick:(id)sender;
- (void)addCreaditText:(NSString*)str;
- (void)clearCreaditText:(bool)isAni;
- (void)showImg:(id)img;
- (void)hideImg:(id)img;

@end
