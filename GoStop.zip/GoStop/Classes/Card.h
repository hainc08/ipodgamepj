#import <UIKit/UIKit.h>
#import "SoundEffect.h" 

@interface Card : UIView{
    IBOutlet id CardImg;
    IBOutlet id BackImg;
    IBOutlet id EableImg;
	int m_idx;
	int m_type;		//광, 피, 띠, 열, 쌍피 등을 구분하는 타입
	int cardType;
	bool isBomb;
	
    SoundEffect *tickSound;
	CGPoint m_pos;
}

@property (readwrite) CGPoint m_pos;
@property (readwrite) int cardType;
@property (readwrite) int m_idx;
@property (readwrite) bool isBomb;

- (int)getMark;
- (void)setShow:(bool)isShow;
- (void)setCard:(int)idx;
- (void)playSound;
- (void)setEable:(bool)eable;

- (void)moveTo:(CGPoint)pos:(bool)isZoom;
- (void)moveTo:(int)x:(int)y:(bool)isZoom;
- (void)moveToNoAni:(CGPoint)pos:(bool)isZoom;
- (void)moveToNoAni:(int)x:(int)y:(bool)isZoom;

- (void)Zoom:(bool)isZoom;

@end
