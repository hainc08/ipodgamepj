#import "BlankView.h"

@implementation BlankView

- (void)setPosSize:(CGPoint)pos:(NSString*)style;
{
	[self setCenter:pos];
}

@end
