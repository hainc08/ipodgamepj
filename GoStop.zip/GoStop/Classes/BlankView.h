#import <UIKit/UIKit.h>

@interface BlankView : UIView{

}

- (void)setPosSize:(CGPoint)pos:(NSString*)style;

@end
