#import <UIKit/UIKit.h>
#import "BaseView.h"
#import "Card.h"
#import "Player.h"
#import "Mission.h"
#import "BlankView.h"
#import "SoundEffect.h" 

@interface GameView : BaseView {
	Card *cards[48];
	Card *deck[48];
	Card *groundCard[12][4];
	Player *jabbuck[12];
	Mission *mission;
	CGPoint groundPos[12];

	int deckCount;
	int groundCount;
	int selectIdx;
	int turnPhase;
	int turnCount;
	bool cardInit;

	int nagariDouble;
	int nagariCount;

	IBOutlet id goStopView;
	IBOutlet id goButton;
	IBOutlet id testButton;
    IBOutlet id stopButton;

	int bonusCount;
    IBOutlet id scoreText;
    IBOutlet id bonusText1;
    IBOutlet id bonusText2;
    IBOutlet id bonusText3;
    IBOutlet id pointText;
    IBOutlet id finalMoney;

    IBOutlet id scoreText_2;
    IBOutlet id bonusText1_2;
    IBOutlet id bonusText2_2;
    IBOutlet id bonusText3_2;
    IBOutlet id pointText_2;
	
	IBOutlet id gameOverView;
	IBOutlet id okButton;
	IBOutlet id gotoMainButton;
    IBOutlet id winnerText;
	
    IBOutlet id cardDeck;
    IBOutlet id playerHand;
    IBOutlet id manScore;
    IBOutlet id cpuScore;
    IBOutlet id playerName;
    IBOutlet id flashMsg;
    IBOutlet id backImg;
	BlankView* ground;
	
    IBOutlet id missionComplete;
    IBOutlet id missionFail;	
    IBOutlet id x2;
    IBOutlet id x3;

    IBOutlet id goImg;
	UInt32 goTick;

	Player *CPU, *MAN;
	
	int ggang;

	int selectCardMark;
    SoundEffect *jjockSound;
    SoundEffect *goSound;
    SoundEffect *stopSound;
	
	Card* reserveCard;
	
	int phaseTraking[200];
	int trakingIdx;
}

- (IBAction)ButtonClick:(id)sender;
- (void)showFlashMsg:(NSString*)msg;
- (void)goShow:(int)go;
- (void)goHide;
- (void)addBonusText:(NSString*)str go:(bool)isGo;
- (int)FillScoreInfo:(Player*)winner go:(bool)isGo;
- (void)setUpGameBoard;
- (Card *)getCard;
- (void)changePhase:(int)phase;
- (void)giveToGround:(Card *)card:(bool)withSound;
- (int)hitToGround:(Card *)card withSound:(bool)sound;
- (void)eatCard:(Player*)player:(int)mark:(int)idx;
- (bool)eatFromGround:(Player*)player:(Card *)card;
- (void)turnPlay:(Player*)player:(Card *)card1:(Card *)card2;
- (void)GameOver:(Player*)winner;
- (void)getPlayerPi:(Player*)player;
- (void)getPlayer2Pi:(Player*)player;

@end
