#import "Card.h"

@interface Player : NSObject {
	int m_handCardCount;
	int m_eatCardCount[5];
	int m_bombedCardCount;

	Card *reserveCard;
	Card *m_hand[10];
	Card *m_eat[5][22];
	bool m_eatCardFlag[48];
	
	bool m_isCPU;
	int score;

	int goCount;
	int goScore;
	int shakeCount;
}

@property (retain) Card* reserveCard;
@property (readwrite) int score;
@property (readwrite) int goCount;
@property (readwrite) int goScore;
@property (readwrite) int m_handCardCount;
@property (readwrite) int m_bombedCardCount;
@property (readwrite) int shakeCount;

- (void)checkEable:(int)mark;
- (void)resetEable;
- (int)getCardCount:(int)cardType;
- (void)giveToHand:(Card *)card;
- (void)giveToEat:(Card *)card;
- (Card*)getFromHand:(int)idx;
- (Card*)readFromHand:(int)idx;
- (void)resetPLayer:(bool)isCPU;
- (Card*)handCardZoom:(int)idx;
- (Card*)getPiCard;
- (Card*)get2PiCard;
- (bool)isHandCardOK:(int)idx;
- (bool)isEatCardOK:(int)idx;
- (void)go;
- (void)removeBomb:(int)mark;
- (Card*)getFromHand_Mark:(int)mark;
- (void)sortCard;

@end
