#import <UIKit/UIKit.h>
#import "BaseView.h"

@interface GameLogoView : BaseView {
    IBOutlet id logoImg;
	int step;
	float alpha;	
}

@end

