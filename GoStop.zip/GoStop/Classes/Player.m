#import "Player.h"
#import "../BaseClasses/ToDoManager.h"

@implementation Player

@synthesize score;
@synthesize goCount;
@synthesize goScore;
@synthesize m_handCardCount;
@synthesize m_bombedCardCount;
@synthesize shakeCount;
@synthesize reserveCard;

- (void)resetPLayer:(bool)isCPU
{
	m_isCPU = isCPU;
	m_handCardCount = 0;
	m_bombedCardCount = 0;
	shakeCount = 0;
	
	for (int i=0; i<10; ++i)
	{
		m_hand[i] = NULL;
	}
	for (int i=0; i<48; ++i)
	{
		m_eatCardFlag[i] = false;
	}
	for (int i=0; i<5; ++i)
	{
		m_eatCardCount[i] = 0;
		for (int j=0; j<22; ++j)
		{
			m_eat[i][j] = NULL;
		}
	}
	
	goCount = 0;
	score = 0;
	goScore = 4;
}

- (bool)isHandCardOK:(int)idx
{
	return (m_handCardCount > idx);
}

- (bool)isEatCardOK:(int)idx
{
	if (reserveCard != NULL)
	{
		if (reserveCard.m_idx == idx) return true;
	}
	
	return m_eatCardFlag[idx];
}

- (void)go
{
	++goCount;
	goScore = score;
}

- (Card*)getFromHand:(int)idx
{
	if (m_handCardCount <= idx) return NULL;

	Card* card = m_hand[idx];
	--m_handCardCount;
	for (int i=idx; i<m_handCardCount; ++i)
	{
		m_hand[i] = m_hand[i+1];
		CGPoint pos = m_hand[i].m_pos;
		if (m_isCPU) pos.x = 304 - (i * 32);
		else pos.x = 16 + (i * 32);
		[[ToDoManager getInstance] addCardMove:m_hand[i] pos:pos isAni:true isZoom:false isShow:false waitNext:0]; 
	}
	m_hand[m_handCardCount] = NULL;
	return card;
}

- (Card*)getPiCard
{
	Card * card = NULL;

	if (m_eatCardCount[3] > 0)
	{
		--m_eatCardCount[3];
		card = m_eat[3][m_eatCardCount[3]];
		m_eat[3][m_eatCardCount[3]] = NULL;
		m_eatCardFlag[card.m_idx] = false;
	}
	else if (m_eatCardCount[4] > 0)
	{
		--m_eatCardCount[4];
		card = m_eat[4][m_eatCardCount[4]];
		m_eat[4][m_eatCardCount[4]] = NULL;
		m_eatCardFlag[card.m_idx] = false;
	}

	return card;
}

- (Card*)get2PiCard
{
	Card * card = NULL;
	
	if (m_eatCardCount[4] > 0)
	{
		--m_eatCardCount[4];
		card = m_eat[4][m_eatCardCount[4]];
		m_eat[4][m_eatCardCount[4]] = NULL;
		m_eatCardFlag[card.m_idx] = false;
	}
	
	return card;
}

- (Card*)handCardZoom:(int)idx
{
	for (int i=0; i<10; ++i)
	{
		if (m_hand[i] != NULL)
		{
			[m_hand[i] Zoom:(idx == i)];
		}
	}
	
	if(idx < 0) return NULL;

	return m_hand[idx];
}

- (void)giveToHand:(Card *)card
{
	if (m_isCPU)
	{
		[[ToDoManager getInstance] addCardMove:card pos:CGPointMake(304 - (m_handCardCount * 32), 40) isAni:true isZoom:false isShow:false waitNext:1];
	}
	else
	{
		[[ToDoManager getInstance] addCardMove:card pos:CGPointMake(16 + (m_handCardCount * 32), 445) isAni:true isZoom:false isShow:true waitNext:1];
	}
		
	m_hand[m_handCardCount] = card;
	
	int sameCount = 0;
	for (int i=0; i<m_handCardCount; ++i)
	{
		if ([m_hand[i] getMark] == [card getMark]) ++sameCount;
	}

	++m_handCardCount;
	
	if (sameCount >= 2)
	{
		for (int i=0; i<m_handCardCount; ++i)
		{
			if ([m_hand[i] getMark] == [card getMark]) [m_hand[i] setIsBomb:true];
		}
	}
	else [card setIsBomb:false];
}

- (void)removeBomb:(int)mark
{
	for (int i=0; i<m_handCardCount; ++i)
	{
		if ([m_hand[i] getMark] == mark) [m_hand[i] setIsBomb:false];
	}
}

- (Card*)readFromHand:(int)idx
{
	return m_hand[idx];
}

- (Card*)getFromHand_Mark:(int)mark
{
	for (int i=0; i<m_handCardCount; ++i)
	{
		if ([m_hand[i] getMark] == mark) return [self getFromHand:i];
	}
	
	return NULL;
}

- (void)giveToEat:(Card *)card;
{
	CGPoint pos;
	int cardType = card.cardType;
	m_eatCardFlag[card.m_idx] = true;

	switch (cardType) {
		case 0:
			pos = CGPointMake(16 + (m_eatCardCount[0] * 10), 113);
			break;
		case 1:
			pos = CGPointMake(90 + (m_eatCardCount[1] * 10), 94);
			break;
		case 2:
			pos = CGPointMake(90 + (m_eatCardCount[2] * 10), 140);
			break;
		case 3:
			if ((m_eatCardCount[3] + m_eatCardCount[4]) > 17)
			{
				pos = CGPointMake(214 + ((m_eatCardCount[3] + m_eatCardCount[4] - 18) * 10), 140);
			}
			else if ((m_eatCardCount[3] + m_eatCardCount[4]) > 8)
			{
				pos = CGPointMake(214 + ((m_eatCardCount[3] + m_eatCardCount[4] - 9) * 10), 113);
			}
			else
			{
				pos = CGPointMake(214 + ((m_eatCardCount[3] + m_eatCardCount[4]) * 10), 94);
			}
			break;
		 case 4:
			if (m_eatCardCount[4] > 8)
			{
				pos = CGPointMake(214 + ((m_eatCardCount[4] - 9) * 10), 113);
			}
			else
			{
				pos = CGPointMake(214 + (m_eatCardCount[4] * 10), 94);
			}
			break;
	}

	if (!m_isCPU) pos.y += 250;

	[[ToDoManager getInstance] addCardMove:card pos:pos isAni:true isZoom:false isShow:true waitNext:1];	
	m_eat[cardType][m_eatCardCount[cardType]] = card;
	++m_eatCardCount[cardType];
	
	if (cardType == 4)
	{
		for (int i=0; i<m_eatCardCount[3]; ++i)
		{
			if ((i + m_eatCardCount[4]) > 17)
			{
				pos = CGPointMake(214 + ((i + m_eatCardCount[4] - 18) * 10), 140);
			}
			else if ((i + m_eatCardCount[4]) > 8)
			{
				pos = CGPointMake(214 + ((i + m_eatCardCount[4] - 9) * 10), 113);
			}
			else
			{
				pos = CGPointMake(214 + ((i + m_eatCardCount[4]) * 10), 94);
			}

			if (!m_isCPU) pos.y += 250;

			[[ToDoManager getInstance] addCardMove:m_eat[3][i] pos:pos isAni:true isZoom:false isShow:true waitNext:0];
		}
	}
}

- (int)getCardCount:(int)cardType
{
	int cardCount = m_eatCardCount[cardType];
	if (reserveCard != NULL)
	{
		if (reserveCard.cardType == cardType) ++cardCount;
	}
	return cardCount;
}

- (void)sortCard
{
	Card *tempHand[m_handCardCount];
	
	for (int i=0; i<m_handCardCount; ++i)
	{
		int idx = 0;

		for (int j=0; j<m_handCardCount; ++j)
		{
			if (i != j)
			{
				if ([m_hand[i] getMark] == [m_hand[j] getMark])
				{
					if (i > j) ++idx;
				}
				else if ([m_hand[i] getMark] > [m_hand[j] getMark]) ++idx;
			}
		}
		
		tempHand[idx] = m_hand[i];

		if (m_isCPU)
		{
			[[ToDoManager getInstance] addCardMove:m_hand[i] pos:CGPointMake(304 - (idx * 32), 40) isAni:true isZoom:false isShow:false waitNext:0];
		}
		else
		{
			[[ToDoManager getInstance] addCardMove:m_hand[i] pos:CGPointMake(16 + (idx * 32), 445) isAni:true isZoom:false isShow:true waitNext:0];
		}
	}
	
	for (int i=0; i<m_handCardCount; ++i)
	{
		m_hand[i] = tempHand[i];
	}
}

- (void)checkEable:(int)mark
{
	for (int i=0; i<m_handCardCount; ++i)
	{
		if ([m_hand[i] getMark] == mark) [m_hand[i] setEable:true];
	}
}

- (void)resetEable
{
	for (int i=0; i<m_handCardCount; ++i)
	{
		[m_hand[i] setEable:false];
	}
}

@end