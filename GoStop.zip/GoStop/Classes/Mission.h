#import <UIKit/UIKit.h>
#import "Card.h"
#import "Player.h"

@interface Mission : UIView{
	Card *cards[3];
	int missionIdx;
	int jjockCount;
	int panCount;
	
    IBOutlet id missionImg1;
    IBOutlet id missionImg2;

    IBOutlet id x2;
    IBOutlet id x3;
}

@property (readwrite) int jjockCount;
@property (readwrite) int panCount;
@property (readwrite) int missionIdx;

- (void)init;
- (void)setMission:(int)idx;
- (bool)checkMission:(Player*)player;

@end
