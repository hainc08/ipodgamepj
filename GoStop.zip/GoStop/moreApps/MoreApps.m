#import "MoreApps.h"
#import "ViewManager.h"

@implementation MoreApps

- (id)initWithCoder:(NSCoder *)coder {
	self = [super initWithCoder:coder];
	return self;
}

- (id)initWithFrame:(CGRect)frame {
	self = [super initWithFrame:frame];
	return self;
}

- (void)reset:(NSObject*)param
{
	[super reset:param];

	[waiter setAlpha:0];

	if ([[Reachability sharedReachability] internetConnectionStatus] == NotReachable)
	{
		[checkWIFI setText:@"Please Check Network"];
		[gotoSafari setAlpha:0];
	}
	else
	{
		[checkWIFI setText:@"Network Check OK"];
		[gotoSafari setAlpha:1];
	}
}

- (IBAction)ButtonClick:(id)sender
{
	if (sender == gotoSafari)
	{
		NSString *urlAddress = @"http://mallim.com/sasin/moreapps/white.php";
		NSURL *url = [NSURL URLWithString:[urlAddress stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
		[[UIApplication sharedApplication] openURL:url];
	}
	else if (sender == mainmenu)
	{
		[[ViewManager getInstance] changeView:@"MainMenuView"];
	}
}

@end
