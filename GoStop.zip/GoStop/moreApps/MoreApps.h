#import <UIKit/UIKit.h>
#import "BaseView.h"
#import "Reachability.h"

@interface MoreApps : BaseView {
    IBOutlet id checkWIFI;

    IBOutlet id gotoSafari;

    IBOutlet UIActivityIndicatorView* waiter;
	
    IBOutlet id mainmenu;
}

- (IBAction)ButtonClick:(id)sender;

@end

