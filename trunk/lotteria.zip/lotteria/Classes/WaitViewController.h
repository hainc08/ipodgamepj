//
//  WaitViewController.h
//  lotteria
//
//  Created by embmaster on 11. 3. 8..
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WaitViewController : UIViewController {

}

@end
