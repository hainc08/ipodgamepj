//
//  XansimAppDelegate.m
//  Xansim
//
//  Created by 재영 최 on 10. 3. 3..
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "XansimAppDelegate.h"
#import "MainController.h"
@implementation XansimAppDelegate

@synthesize window;
@synthesize mainController;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
	[window addSubview:mainController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
	[mainController release];
    [super dealloc];
}


@end
