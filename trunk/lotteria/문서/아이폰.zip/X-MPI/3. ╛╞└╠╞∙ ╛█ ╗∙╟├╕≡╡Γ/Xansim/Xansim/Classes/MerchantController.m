//
//  MerchantController.m
//  Xansim
//
//  Created by 재영 최 on 10. 3. 3..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MerchantController.h"
#import "AnsimController.h";

@implementation MerchantController

@synthesize ansimController;
@synthesize x_goodname;
@synthesize x_amountField;
@synthesize cardData;
@synthesize cardCode;
@synthesize cardPicker;

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

-(IBAction)backgroundClick:(id)sender {
	[x_amountField resignFirstResponder];
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.

- (void)viewDidLoad {
	NSArray *array=[[NSArray alloc] initWithObjects:@"삼성카드",@"신한카드",@"롯데카드",@"현대카드",@"NH카드",@"제주카드",nil];
	NSArray *code =[[NSArray alloc] initWithObjects:@"51",@"41",@"71",@"61",@"91",@"42",nil];
	//91:NH , 51:삼성 ,   61:현대 ,   71:롯데,    41:신한  ,42:제주
	self.cardData=array;
	self.cardCode=code;
	[array release];
	[code release];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

//인증결과 완료값이 여기로 리턴된다.
-(void)returnAnsimValue:(NSString *)r_code
					msg:(NSString *)r_msg
					xid:(NSString *)r_xid
					eci:(NSString *)r_eci
				   cavv:(NSString *)r_cavv
				 cardno:(NSString *)r_cardno
			   joincode:(NSString *)r_joincode{
	
	NSLog(@"%@",r_code);
	NSLog(@"%@",r_msg);
	NSLog(@"%@",r_eci);
	NSLog(@"%@",r_cavv);
	NSLog(@"%@",r_cardno);
	NSLog(@"%@",r_joincode);
	

}

-(IBAction) settleButtonPressed{
	
	/* 스마트폰에서는 세이블 관련 서비스는 제공하지 않습니다.
	   공인인증서 사용문제로 신한하이세이브 삼성 슈퍼세이브, 롯데 쇼핖세이브등은 지원하진 않습니다.
	 */

	NSInteger row=[cardPicker selectedRowInComponent:0];
	
	NSLog(@"row===%d",row);
	
	////91:NH , 51:삼성 ,   61:현대 ,   71:롯데,    41:신한
	NSString *x_cardtype=[cardCode objectAtIndex:row];
	NSLog(@"x_cardtype===%@",x_cardtype);

	NSString *x_mname=@"테스트쇼핑_Test";
	NSString *x_businessnum=@"1231231230";//쇼핑몰 사업자 번호
	NSString *x_currency=@"410"; //410:원화
	//호스팅 url은 PG사에 문의하시거나 데이콤을 이용하세요.
	//호스팅 응답받을 url
	NSString *x_receiveurl=@"https://mpi.dacom.net/XMPI/m_hostAgent12.jsp";
	//호스팅 시작url;
	NSString *x_hosturl=@"https://mpi.dacom.net/XMPI/m_hostAgent01.jsp";
	//NSString *x_hosturl=@"http://192.168.1.151:7090/xmpi/itest/test.html";
	//NSString *x_hosturl=@"http://192.168.1.151:7090/xmpi/host/hostAgent12_test.jsp";
	//NSString *x_hosturl=@"http://192.168.1.151:7090/xmpi/samsung/301.html";

	NSLog(@"urlStr===%@",self.x_goodname.text);
	AnsimController *ansimController =[[AnsimController alloc] initWithNibName:@"AnsimView" bundle:nil];
	

	[ansimController setAnsimValue:x_mname 
					   businessnum: x_businessnum 
						currency: x_currency
						cardtype: x_cardtype 
						receiveurl: x_receiveurl 
						   hosturl: x_hosturl
							amount:x_amountField.text
						  goodname:x_goodname.text];
	
	
	self.ansimController=ansimController;
	self.ansimController.delegate=self;
	[UIView beginAnimations:@"View Flip" context:nil];
    [UIView setAnimationDuration:2.0];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	
	
	
	[self.view insertSubview:ansimController.view atIndex:9];
	[ansimController release];
	[UIView setAnimationTransition:
	 UIViewAnimationTransitionCurlUp
						   forView:self.view cache:YES];
	[UIView commitAnimations];
	//[super viewDidLoad];
}

-(IBAction) amountFieldDoneEditing:(id)sender{
	[sender resignFirstResponder];
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	self.cardPicker = nil;
	self.cardData = nil;
	[super viewDidUnload];
}


- (void)dealloc {
	[ansimController release];
	[cardPicker release];
	[cardData release];
	[cardCode release];
    [super dealloc];
}

#pragma mark -
#pragma mark Picker Data Source Methods
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
	return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
	return [cardData count];
}
#pragma mark Picker Delegate Methods
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [cardData objectAtIndex:row];
}

@end
