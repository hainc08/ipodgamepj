//
//  XansimAppDelegate.h
//  Xansim
//
//  Created by 재영 최 on 10. 3. 3..
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainController;
@interface XansimAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	MainController *mainController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MainController *mainController;

@end

