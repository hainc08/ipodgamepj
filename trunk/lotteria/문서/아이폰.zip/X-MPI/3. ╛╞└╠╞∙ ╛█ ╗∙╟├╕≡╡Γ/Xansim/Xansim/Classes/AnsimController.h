//
//  AnsimController.h
//  Xansim
//
//  Created by 재영 최 on 10. 3. 3..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol AnsimDelegate;

@interface AnsimController : UIViewController {
	UIWebView *webView;
	NSString *x_mname;
	NSString *x_businessnum;
	NSString *x_cardtype;
	NSString *x_hosturl;
	NSString *x_currency;
	NSString *x_receiveurl;
	NSString *x_amount;
	id<AnsimDelegate> delegate;
	
}
@property (nonatomic,retain)IBOutlet UIWebView *webView;
@property (nonatomic,retain)IBOutlet NSString *x_mname;
@property (nonatomic,retain)IBOutlet NSString *x_businessnum;
@property (nonatomic,retain)IBOutlet NSString *x_cardtype;
@property (nonatomic,retain)IBOutlet NSString *x_hosturl;
@property (nonatomic,retain)IBOutlet NSString *x_currency;
@property (nonatomic,retain)IBOutlet NSString *x_receiveurl;
@property (nonatomic,retain)IBOutlet NSString *x_amount;
-(IBAction) closeButton;
-(IBAction) goButton;
-(void)setAnsimValue:(NSString *) x_mname 
	businessnum:(NSString *) x_businessnum 
    currency:(NSString *) x_currency
	cardtype:(NSString *) x_cardtype 
	receiveurl:(NSString *) x_receiveurl 
	hosturl:(NSString *) x_hosturl 
			amount:(NSString *)x_amount
			goodname:(NSString *)x_goodname;

@property (nonatomic,assign) id<AnsimDelegate> delegate;

@end
@protocol AnsimDelegate <NSObject>;
@required 
-(void)returnAnsimValue:(NSString *)r_code
					msg:(NSString *)r_msg
					xid:(NSString *)r_xid
					eci:(NSString *)r_eci
					cavv:(NSString *)r_cavv
					cardno:(NSString *)r_cardno
					joincode:(NSString *)r_joincode;
@end


