//
//  AnsimController.m
//  Xansim
//
//  Created by 재영 최 on 10. 3. 3..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "AnsimController.h"


@implementation AnsimController

@synthesize x_mname;
@synthesize x_businessnum;
@synthesize x_hosturl;
@synthesize x_cardtype;
@synthesize x_currency;
@synthesize x_receiveurl;
@synthesize x_amount;
@synthesize webView;

@synthesize delegate;
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	
	
	
	//(필수 ) 삼성카드 가맹점 번호 사업자 번호 필수 
	NSString *APVL_CHAIN_NO_SS=@""; //삼성카드 가맹점 번호
	NSString *APVL_SELLER_ID=@""; //삼성카드 사업자번호 

	//현대카드 세이브 이용시 (공인인증서 모바일 사용불가로 처리안됨.)
	//NSString *APVL_CHAIN_NO_HD=@"11111"; //hyundaicard 가맹점 번호
	//NSString *APVL_SELLER_HD=@"11111"; //hyundaicard 사업자번호 
	//NSString *APVL_SS_USEYN_HD=@"11111"; //Hyundaicard 세이브 사용여부 Y/N 

	
	

	
	NSString *paramStr = [[NSString alloc] initWithFormat: @"X_MNAME=%@&X_MBUSINESSNUM=%@&X_CARDTYPE=%@&X_CURRENCY=%@&X_RECEIVEURL=%@&X_AMOUNT=%@&APVL_CHAIN_NO_SS=%@&APVL_SELLER_ID=%@",x_mname, x_businessnum,x_cardtype,x_currency,x_receiveurl,x_amount,APVL_CHAIN_NO_SS,APVL_SELLER_ID];
	
	int timeout=10.0;
	NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:[NSURL URLWithString:x_hosturl]
														  cachePolicy:NSURLRequestReloadIgnoringCacheData 
													  timeoutInterval:timeout];
	
	[request setHTTPMethod:@"POST"];
	[request setHTTPBody:[paramStr dataUsingEncoding:NSUTF8StringEncoding]];
	[paramStr release];
	
	
	webView.delegate = self;
	[webView loadRequest:request];	
    [super viewDidLoad];
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
-(IBAction) closeButton{
	/*
	NSString *k_mname=@"Test";
	NSString *strScript = [NSString stringWithFormat:
						   @"var fromApp = document.getElementById('fromApp');\
						   fromApp.value = '%@';",k_mname ];
	[webView stringByEvaluatingJavaScriptFromString:strScript];
	*/


	[self.view removeFromSuperview];
	

}
-(IBAction) goButton{
	//[MerchantController getAcs];
	
	NSString *urlStr = [[NSString alloc] initWithFormat: @"http://yahoo.co.kr"];
	NSLog(@"urlStr===%@",urlStr);
	NSURL *url = [NSURL URLWithString: [NSString stringWithFormat: urlStr]];
	
	NSURLRequest *req = [NSURLRequest requestWithURL:url];
	
	webView.delegate = self;
	[webView loadRequest:req];;
	
}
- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}


-(void)setAnsimValue:(NSString *) x_mname 
		 businessnum:(NSString *) x_businessnum 
			currency:(NSString *) x_currency
			cardtype:(NSString *) x_cardtype 
		  receiveurl:(NSString *) x_receiveurl 
			 hosturl:(NSString *) x_hosturl
			  amount:(NSString *)x_amount
			goodname:(NSString *)x_goodname{
	
	NSLog(@"x_mname===%@",x_mname);
	NSLog(@"x_businessnum===%@",x_businessnum);
	NSLog(@"x_currency===%@",x_currency);
	NSLog(@"x_cardtype===%@",x_cardtype);
	NSLog(@"x_receiveurl===%@",x_receiveurl);
	NSLog(@"x_hosturl===%@",x_hosturl);	
	NSLog(@"x_amount===%@",x_amount);	
	
	self.x_hosturl=x_hosturl;
	self.x_mname=x_mname;
	self.x_businessnum=x_businessnum;
	self.x_cardtype=x_cardtype;
	self.x_currency=x_currency;
	self.x_receiveurl=x_receiveurl;
	self.x_amount=x_amount;	
    


}
- (void)webViewDidFinishLoad:(UIWebView *)webView1 { 
	NSString* frm = [webView1 stringByEvaluatingJavaScriptFromString: @"document.forms[0].name"]; 

	if ( YES==[@"X_RESULT" isEqualToString:frm]){
		 NSString* x_resp = [webView1 stringByEvaluatingJavaScriptFromString: @"document.X_RESULT.X_RESP.value"]; 
		 NSString* x_msg= [webView1 stringByEvaluatingJavaScriptFromString: @"document.X_RESULT.X_MSG.value"]; 
		 NSString* x_xid = [webView1 stringByEvaluatingJavaScriptFromString: @"document.X_RESULT.X_XID.value"]; 
		 NSString* x_eci = [webView1 stringByEvaluatingJavaScriptFromString: @"document.X_RESULT.X_ECI.value"]; 
		 NSString* x_cavv = [webView1 stringByEvaluatingJavaScriptFromString: @"document.X_RESULT.X_CAVV.value"]; 
		 NSString* x_cardno = [webView1 stringByEvaluatingJavaScriptFromString: @"document.X_RESULT.X_CARDNO.value"]; 
		 NSString* x_joincode = [webView1 stringByEvaluatingJavaScriptFromString: @"document.X_RESULT.X_JOINCODE.value"]; 
		 NSString* x_hs_useamt_sh = [webView1 stringByEvaluatingJavaScriptFromString: @"document.X_RESULT.X_HS_USEAMT_SH.value"]; 
		
		NSLog(@"============카드사에서 내려준 안심클릭 응답값입니다. ============");
		NSLog(@"x_resp가 0000일경우만 정상처리 하시면 됩니다.");

		NSLog(@"x_resp=====>%@", x_resp);
		NSLog(@"x_msg=====>%@", x_msg);
		NSLog(@"x_xid=====>%@", x_xid);
		NSLog(@"x_eci=====>%@", x_eci);
		NSLog(@"x_cavv=====>%@", x_cavv);
		NSLog(@"x_cardno=====>%@",x_cardno);
		NSLog(@"x_joincode=====>%@",x_joincode);
		NSLog(@"x_hs_useamt_sh=====>%@",x_hs_useamt_sh);
		NSLog(@"============카드사에서 내려준 안심클릭 응답 ============");
		if ([x_resp isEqualToString:@"0000"]){
			NSLog(@"****카드사 인증이 정상완료 되었습니다. VAN에서 제공하는 승인모듈을 테우시면 됩니다.******");
			UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"인증결과" 
														  message:@"카드인증이 완료되었습니다" 
														 delegate:nil 
												cancelButtonTitle:@"OK"
												otherButtonTitles:nil];
			[alert show];
			[alert release];
			
			//상점화면으로 값을 넘긴다.
			[self.delegate returnAnsimValue:x_resp
										msg:(NSString *)x_msg
										xid:(NSString *)x_xid
										eci:(NSString *)x_eci
									   cavv:(NSString *)x_cavv
									 cardno:(NSString *)x_cardno
								   joincode:(NSString *)x_joincode 
			 ];
			
		} else {
			UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"인증결과" 
														  message:x_msg 
														 delegate:nil 
												cancelButtonTitle:@"OK" 
												otherButtonTitles:nil];
			[alert show];
			[alert release];			
		}
		
		
	
		[self.view removeFromSuperview];
	
	}

}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
