//
//  MainController.h
//  Xansim
//
//  Created by 재영 최 on 10. 3. 3..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MerchantController;
@class AnsimController;

@interface MainController : UIViewController {
	MerchantController *mController;
	AnsimController *aController;
	NSString *temp;

}
@property (retain ,nonatomic) MerchantController *mController;
@property (retain ,nonatomic) AnsimController *aController;
@property (retain ,nonatomic) NSString *temp;

@end
