//
//  MerchantController.h
//  Xansim
//
//  Created by 재영 최 on 10. 3. 3..
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AnsimController.h";

@interface MerchantController : UIViewController <AnsimDelegate,UIPickerViewDelegate,UIPickerViewDataSource>{
	
	AnsimController *ansimController;
	MerchantController *merchantController;
	UITextField *x_goodname;	//상품명
	UITextField *x_amountField; //상품금액
	
	NSString *r_cardno;
	//카드사 선택 select
	UIPickerView *cardPicker;
	NSArray		 *cardData;
	NSArray		 *cardCode;	//카드사 선택에 대한 카드사 코드 이다. //91:NH , 51:삼성 ,   61:현대 ,   71:롯데,    41:신한
	
}

@property (nonatomic,retain) AnsimController *ansimController;
@property (nonatomic,retain) MerchantController *merchantController;

//
@property (nonatomic,retain) IBOutlet UITextField *x_amountField;
@property (nonatomic,retain) IBOutlet UITextField *x_goodname;

//카드사 선택 selected
@property (nonatomic,retain) IBOutlet UIPickerView *cardPicker;
//카드사 명 
@property (nonatomic,retain) NSArray *cardData;
//카드사 코드 
@property (nonatomic,retain) NSArray *cardCode;

@property (nonatomic,retain) NSString *r_cardno;
//결제버튼 
-(IBAction) settleButtonPressed;
-(IBAction) amountFieldDoneEditing:(id)sender;
-(IBAction) backgroundClick:(id)selder;


@end
